#!/usr/bin/env python

import os
from setuptools import setup, find_packages

def package_files(directory):
    paths = []
    for (path, directories, filenames) in os.walk(directory):
        for filename in filenames:
            paths.append(os.path.join('..', path, filename))
    return paths

external_files = package_files('hlprobelib/external/packages')

setup_kwargs = {
    'name': 'hlprobe',
    'version': '0.1.0',
    'description': 'Monitor Scout probe',
    'author': 'Simon Ekstrand',
    'author_email': 'driftopsyd@cygate.se',
    'url': 'https://www.monitorscout.com/',
    'license': 'BSD',
    'packages': find_packages(),
    'scripts': ['hlprobe'],
    'options': {},
    'include_package_data': True,
    'package_data': {
        '': external_files
    }
}

setup(**setup_kwargs)
