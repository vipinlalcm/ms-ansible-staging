#!/usr/bin/env python

import hlprobelib.utils
hlprobelib.utils.DEFAULT_MONITOR_BINARY_PATHS.append('../hlprobe-binaries/')
hlprobelib.utils.DEFAULT_MONITOR_BINARY_PATHS.append('/usr/local/sbin') # nagios plugins from homebrew

from twisted.internet import reactor
from twisted.internet import defer
from hlprobelib.jobs.registry import job_registry
import hlprobelib.jobs.locals
from hlprobelib.hlprobe import import_external_jobs

#import_external_jobs('/Users/simon/src/hl/ms-ipeer-probe-plugins/active')


JOB_NAME = 'monitor-http-ms'
#JOB_ARGS = ('213.180.89.67', 30, 1433, 'mrcuster', 'Aibeeth6aok3', 'mrcuster')
JOB_ARGS = ('localhost', 120, 'http://bob.ipeer.se/', '', False, 0)

def d_sleep(length, deferred=None):
    if deferred:
        deferred.callback(True)
        ret = True
    else:
        ret = defer.Deferred()
        reactor.callLater(length, d_sleep, length, ret)
    return ret

class FakeQueue(object):
    def jobComplete(*args, **kwargs):
        pass

@defer.inlineCallbacks
def run_job(job_name, job_args):
    job_class = job_registry.jobtypes.get(job_name)
    job = job_class(FakeQueue(), 'd1', 'j1', *job_args)
    job.run()
    while True:
        if job.completed:
            break
        yield d_sleep(0.1)
    print job.result
    reactor.stop()

if __name__ == '__main__':
    reactor.callWhenRunning(run_job, JOB_NAME, JOB_ARGS)
    reactor.run()
