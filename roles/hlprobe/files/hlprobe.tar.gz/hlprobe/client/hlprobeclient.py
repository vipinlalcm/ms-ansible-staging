#!/usr/bin/env python

from optparse import OptionParser
import sys
from xmlrpclib import ServerProxy, Error

DEFAULT_SERVER = 'localhost:11001'

class CommandRunner(object):
    def __init__(self):
        self.server = None
        self.commands = {}

    def register(self, command):
        self.commands[command.name] = command

    def run(self, name, *args, **kwargs):
        if self.server is None:
            raise Exception('server attribute must be set to run commands')
        if name not in self.commands:
            raise Exception('command not found')
        cmd = self.commands[name](self.server)
        return cmd.run(*args, **kwargs)

    def _cmdSorter(self, x, y):
        if x.name < y.name:
            return -1
        if x.name == y.name:
            return 0
        if x.name > y.name:
            return 1

    def listCommands(self):
        cmds = [cmd for cmd in self.commands.itervalues()]
        cmds.sort(cmp = self._cmdSorter)
        return cmds

commandrunner = CommandRunner()

class BaseCommand(object):
    name = '[UKNOWN]'
    args = 'None'
    default_timeout = 30
    def __init__(self, server):
        self.server = server

    def run(self, *args, **kwargs):
        raise Exception('command forgot to override run method')

    def __str__(self):
        return self.name

    def _makeBool(self, val):
        if type(val) == bool:
            return val
        val = val.lower()
        if val == 'true':
            return True
        elif val == 'false':
            return False
        else:
            raise Exception('not a bool: "%s"' % (val))

    def _makeInt(self, val):
        try:
            val = int(val)
        except ValueError:
            raise Exception('not an int: "%s"' % (val))
        return val

    def _makeFloat(self, val):
        try:
            val = float(val)
        except ValueError:
            raise Exception('not a float: "%s"' % (val))
        return val

    def _printDict(self, arg):
        for key in arg:
            print '%s : %s' % (key, arg[key])

class PingCommand(BaseCommand):
    name = 'ping'
    def run(self):
        print self.server.ping()
commandrunner.register(PingCommand)

class ShutdownCommand(BaseCommand):
    name = 'shutdown'
    def run(self):
        print self.server.shutdown()
commandrunner.register(ShutdownCommand)

class JobListCommand(BaseCommand):
    name = 'job.list'
    def run(self):
        for jobinfo in self.server.job.list():
            print jobinfo
commandrunner.register(JobListCommand)

class JobIsCompleteCommand(BaseCommand):
    name = 'job.is_complete'
    args = 'jobid'
    def run(self, jobid):
        print self.server.job.is_complete(jobid)
commandrunner.register(JobIsCompleteCommand)

class JobGetResultCommand(BaseCommand):
    name = 'job.result'
    args = 'jobid [remove_if_complete]'
    def run(self, jobid, remove_if_complete = 'false'):
        print self.server.job.get_result(jobid,
                self._makeBool(remove_if_complete))
commandrunner.register(JobGetResultCommand)

class JobRemoveCommand(BaseCommand):
    name = 'job.remove'
    args = 'jobid'
    def run(self, jobid):
        print self.server.job.remove(jobid)
commandrunner.register(JobRemoveCommand)

class JobRunNoopCommand(BaseCommand):
    name = 'job.run.noop'
    def run(self):
        print self.server.job.run('noop')
commandrunner.register(JobRunNoopCommand)

class JobRunFailCommand(BaseCommand):
    name = 'job.run.fail'
    def run(self):
        print self.server.job.run('fail')
commandrunner.register(JobRunFailCommand)

class JobRunSleepCommand(BaseCommand):
    name = 'job.run.sleep'
    args = 'time(s)'
    def run(self, sleeptime):
        print self.server.job.run('sleep', self._makeInt(sleeptime))
commandrunner.register(JobRunSleepCommand)

class JobRunPingMonitorCommand(BaseCommand):
    name = 'job.run.monitor.ping'
    args = 'hostname'
    def run(self, hostname):
        print self.server.job.run('monitor-ping', hostname,
                self.default_timeout)
commandrunner.register(JobRunPingMonitorCommand)

class JobRunTCPMonitorCommand(BaseCommand):
    name = 'job.run.monitor.tcp'
    args = 'hostname port send_str="" recv_str="" wait_peer_disconnect=False'
    def run(self, hostname, port, send_str = '', recv_str = '',
            wait_peer_disconnect = 'false'):
        print self.server.job.run('monitor-tcp',
                hostname,
                self.default_timeout,
                self._makeInt(port),
                send_str,
                recv_str,
                self._makeBool(wait_peer_disconnect))
commandrunner.register(JobRunTCPMonitorCommand)

class JobRunHTTPMonitorCommand(BaseCommand):
    name = 'job.run.monitor.http'
    args = """hostname port=80 url="/" host="" match_string="" valid_status_codes=".*"
                       invalid_status_codes="^$" use_ssl=false"""
    def run(self, hostname, port = 80, url = '/', host = '', match_string = '',
            valid_status_codes = '.*', invalid_status_codes = '^$',
            use_ssl = 'false'):
        print self.server.job.run('monitor-http',
                hostname,
                self.default_timeout,
                self._makeInt(port),
                url,
                host,
                match_string,
                valid_status_codes,
                invalid_status_codes,
                self._makeBool(use_ssl))
commandrunner.register(JobRunHTTPMonitorCommand)

class JobRunSMTPMonitorCommand(BaseCommand):
    name = 'job.run.monitor.smtp'
    args = """hostname port=25 mail_from="" mail_to="" use_ssl=False use_tls=False
                       use_auth=False username="" password="""""
    def run(self, hostname, port = 25, mail_from = '', mail_to = '',
            use_ssl = 'false', use_tls = 'false',
            use_auth = 'false', username = '', secret = ''):
        print self.server.job.run('monitor-smtp',
                hostname,
                self.default_timeout,
                self._makeInt(port),
                mail_from,
                mail_to,
                self._makeBool(use_ssl),
                self._makeBool(use_tls),
                self._makeBool(use_auth),
                username,
                secret)
commandrunner.register(JobRunSMTPMonitorCommand)

class JobRunPOP3MonitorCommand(BaseCommand):
    name = 'job.run.monitor.pop3'
    args = """hostname port=110 use_ssl=False username="" password=""
                       fetch_matching_message="<regexp> remove_matching_message=False
                       clear_mailbox=False"""
    def run(self, hostname, port = 110, use_ssl = False,
            username = '', password = '', fetch_matching_message = '',
            remove_matching_message = False, clear_mailbox = False):
        print self.server.job.run('monitor-pop3',
                hostname,
                self.default_timeout,
                self._makeInt(port),
                self._makeBool(use_ssl),
                username,
                password,
                fetch_matching_message,
                self._makeBool(remove_matching_message),
                self._makeBool(clear_mailbox))
commandrunner.register(JobRunPOP3MonitorCommand)

class JobRunMailMonitorCommand(BaseCommand):
    name = 'job.run.monitor.mail'
    args = """smtp_server smtp_port pop3_server pop3_port mail_to pop3_username
                       pop3_password remove_matching_message=True clear_mailbox=True"""
    def run(self, smtp_server, smtp_port, pop3_server, pop3_port, mail_to,
            pop3_username, pop3_password, remove_matching_message=True,
            clear_mailbox=True):
        print self.server.job.run('monitor-mail',
                smtp_server,
                self.default_timeout,
                self._makeInt(smtp_port),
                pop3_server,
                self._makeInt(pop3_port),
                mail_to,
                pop3_username,
                pop3_password,
                self._makeBool(remove_matching_message),
                self._makeBool(clear_mailbox))
commandrunner.register(JobRunMailMonitorCommand)

def main():
    usage = 'usage: %prog [-s server[:port]] [command args|-l]'
    parser = OptionParser(usage = usage)
    parser.add_option('-s', '--server', dest = 'server',
            help = 'hlprobe server to connect to, default: localhost:11001')
    parser.add_option('-l', '--list-commands', dest = 'list_commands',
            action = 'store_true',
            help = 'list all available server commands')
    (options, args) = parser.parse_args(sys.argv[1:])

    if options.list_commands:
        for cmd in commandrunner.listCommands():
            print '%-20s : %s' % (cmd.name, cmd.args)
        sys.exit(1)

    if len(args) < 1:
        print 'ERROR: missing command'
        parser.print_help()
        sys.exit(1)

    server = options.server or DEFAULT_SERVER
    port = None
    if ':' in server:
        try:
            server, port = server.split(':')
            port = int(port)
        except:
            print 'ERROR: invalid server'
            parser.print_help()
            sys.exit(1)
    server = ServerProxy('http://%s:%d/' % (server, port or DEFAULT_PORT))
    commandrunner.server = server
    try:
        commandrunner.run(args[0], *args[1:])
    except Exception, e:
        print e

if __name__ == '__main__':
    main()
