from hlprobelib import dpbridge

class JobManager(object):
    def __init__(self, dpbridge_client, job_queue, connectivity_checker):
        self.dpbridge_client = dpbridge_client
        self.job_queue = job_queue
        self.connectivity_checker = connectivity_checker
        dpbridge_client.manager = self
        job_queue.manager = self

    def start(self):
        self.dpbridge_client.connect()

    def dpbridgeMessage(self, msg):
        if not self.connectivity_checker.is_alive:
            return
        self.job_queue.runJob(msg['delegator_id'], msg['job_id'], msg['job_type'], msg['job_args'])

    def jobComplete(self, job):
#        print 'JJJJJJJJJJJJJJJJJJJJJ', job, job.result
        self.dpbridge_client.sendJobresp(job.delegator_id, job.jobid, job.result)
