import sys
import traceback
import time
from twisted.protocols.basic import Int32StringReceiver
from twisted.internet import defer
from twisted.internet.protocol import Factory, ClientFactory
from twisted.application import internet
from twisted.internet import reactor
from twisted.internet import ssl
#from twisted.internet.endpoints import TCP4ClientEndpoint, SSL4ClientEndpoint
from twisted.application import service, app
from twisted.python import log

from hlprobelib import errors
from hlprobelib import log

import msgpack


class DPBridgeProtocol(Int32StringReceiver):
    MAX_LENGTH = 2000000

    def __init__(self, *args, **kwargs):
        self.ping_dc = None
        self.active = True
        self.client = None

    def connectionMade(self):
        self.sendAuth()
        self.ping_dc = reactor.callLater(30, self.sendPing)

    def sendMessage(self, data):
        data = msgpack.dumps(data, use_bin_type=True)
        self.sendString(data)

    def sendPing(self):
        if self.active:
            self.ping_dc = reactor.callLater(30, self.sendPing)
            self.sendMessage({'cmd': 'ping'})

    def cancelPing(self):
        if self.ping_dc:
            self.ping_dc.cancel()
            self.ping_dc = None

    def sendAuth(self):
        self.sendMessage({'cmd': 'auth', 'id': self.factory.client.probe_id, 'key': self.factory.client.probe_key})

    def sendJobresp(self, delegator_id, job_id, result):
        self.sendMessage({'cmd': 'jobresp', 'delegator_id': delegator_id, 'job_id': job_id, 'result': result})

    def stringReceived(self, data):
        data = msgpack.loads(data, encoding='utf-8')
        self.client.messageReceived(data)

    def quit(self):
        self.active = False
        self.transport.loseConnection()

    def connectionLost(self, reason):
        log.msg('DPBridgeProtocol disconnected: %s' % (str(reason)))
        self.active = False
        self.cancelPing()
        if self.client:
            self.client.protocolDisconnected()
            self.client = None

    def lengthLimitExceeded(self, length):
        log.msg('DPBridgeProtocol exceeded protocol length limit: %d' % (length))
        self.transport.loseConnection()

class DPBridgeProtocolFactory(ClientFactory):
    def __init__(self, client):
        self.client = client

    def startedConnecting(self, connector):
#        print 'Started to connect.'
        pass

    def buildProtocol(self, addr):
#        print 'Connected.'
        proto = DPBridgeProtocol()
        proto.factory = self
        self.client.protocolConnected(proto)
        return proto

    def clientConnectionLost(self, connector, reason):
#        print 'Lost connection.  Reason:', reason
        pass

    def clientConnectionFailed(self, connector, reason):
#        print 'Connection failed. Reason:', reason
        self.client.protocolConnectionFailed(reason)


class DPBridgeClient(object):
    def __init__(self, hostname, port, probe_id, probe_key):
        self.manager = None
        self.hostname = hostname
        self.port = port
        self.probe_id = probe_id
        self.probe_key = probe_key
        self.protocol = None
        self.state = 'disconnected'

    def connect(self):
        if self.state != 'disconnected':
            return
        self.state = 'connecting'
        reactor.connectSSL(self.hostname, self.port, DPBridgeProtocolFactory(self), ssl.ClientContextFactory())
#        point = TCP4ClientEndpoint(reactor, self.hostname, self.port)
#        point = SSL4ClientEndpoint(reactor, self.hostname, self.port, ssl.ClientContextFactory())
#        d = point.connect(DPBridgeProtocolFactory(self))
#        d.addCallbacks(self._cbConnect, self._ebConnect)
#        return d

    def protocolConnected(self, protocol):
        log.msg('DPBridgeClient connected to bridge')
        self.state = 'connected'
        self.protocol = protocol
        protocol.client = self

    def protocolConnectionFailed(self, error):
        log.msg('DPBridgeClient failed to connect to bridge: %s' % (str(error)))
        self.state = 'disconnected'
        self.reconnect()

    def protocolDisconnected(self):
        self.state = 'disconnected'
        self.reconnect()

    def reconnect(self):
        reactor.callLater(5, self.connect)

    def messageReceived(self, msg):
        self.manager.dpbridgeMessage(msg)

    def sendJobresp(self, delegator_id, jobid, result):
        if self.protocol:
            self.protocol.sendJobresp(delegator_id, jobid, result)
