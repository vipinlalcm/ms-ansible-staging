import xmlrpclib

def generic_error(msg = ''):
    """A generic xmlrpc error."""
    return xmlrpclib.Fault(1, msg)

def internal_error(msg = 'internal error'):
    """Something went wrong."""
    return xmlrpclib.Fault(101, msg)

def invalid_argument_encoding(msg = 'invalid argument encoding'):
    return xmlrpclib.Fault(102, msg)

def object_not_found(msg = 'object not found'):
    return xmlrpclib.Fault(103, msg)

