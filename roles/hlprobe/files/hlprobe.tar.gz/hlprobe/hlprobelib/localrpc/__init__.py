from hlprobelib.localrpc.rpc import make_rpc_service
