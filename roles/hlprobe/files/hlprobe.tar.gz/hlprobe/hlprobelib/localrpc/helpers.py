import traceback

from hlprobelib import errors
from hlprobelib.localrpc import xmlrpcerrors
from hlprobelib import log

def error_handler(func):
    def handle_errors(*args, **kwargs):
        try:
            ret = func(*args, **kwargs)
            return ret
        except errors.InvalidArgumentEncoding, e:
            return xmlrpcerrors.invalid_argument_encoding()
        except errors.HLProbeError, e:
            log.debug('LocalRPC command raised HLProbeError (%s)' % (str(e)))
            return xmlrpcerrors.generic_error(e.__str__())
        except Exception, e:
            log.msg('LocalRPC command raised unhandled generic exception %s: %s.' % (type(e), e))
            log.msg(traceback.format_exc())
            return xmlrpcerrors.internal_error()
    return handle_errors

def encode_str_args(func):
    def encode_args(*args, **kwargs):
        new_args = []
        for arg in args:
            if type(arg) == str:
                try:
                    arg = arg.decode('utf-8')
                except UnicodeDecodeError:
                    raise errors.InvalidArgumentEncoding()
            new_args.append(arg)
        ret = func(*new_args, **kwargs)
        return ret
    return encode_args

