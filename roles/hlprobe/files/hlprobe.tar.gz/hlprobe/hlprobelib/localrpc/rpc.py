import time
import uuid
from twisted.web import xmlrpc
from twisted.web import server
from twisted.application import internet
from twisted.internet import reactor
from twisted.internet import defer

from hlprobelib.localrpc import helpers
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils

DEFAULT_PORT = 11001

class BaseRPC(xmlrpc.XMLRPC):
    def __init__(self):
        xmlrpc.XMLRPC.__init__(self)

class RootRPC(BaseRPC):
    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_ping(self):
        """Check that the listener is alive.

        Returns the current server time.
        """
        log.debug('LocalRPC.ping received')
        return time.time()
    xmlrpc_ping.signature = []
    xmlrpc_ping.help = 'Returns server time.'

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_shutdown(self):
        log.msg('LocalRPC received shutdown command.')
        reactor.stop()
        return True
    xmlrpc_shutdown.signature = []
    xmlrpc_shutdown.help = 'Shutdown the hlprobe instance.'

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_gethostbyname(self, address):
        log.msg('LocalRPC.gethostbyname called: %s' % (address))
        import socket
        return socket.gethostbyname(address)

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_gc_get_num_objects(self):
        import gc
        log.msg('LocalRPC.gc_get_num_objects called')
        return len(gc.get_objects())

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_gc_get_object_list(self):
        import gc
        log.msg('LocalRPC.gc_get_object_list called')
        ret = []
        # Some objects just don't want to be strings, skip them.
        for obj in gc.get_objects():
            objstr = None
            try:
                objstr = str(obj)
            except:
                pass
            if objstr is None:
                try:
                    objstr = repr(obj)
                except:
                    pass
            if objstr is not None:
                ret.append(objstr)
        return ret

class JobRPC(BaseRPC):
    def __init__(self, job_queue):
        self.job_queue = job_queue
        xmlrpc.XMLRPC.__init__(self)

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_run(self, jobid, jobtype, jobargs):
        log.msg('LocalRPC.job.run recieved a new job request (%s)' % (jobtype))
        job = self.job_queue.runJob(jobid, jobtype, jobargs)
        return job.jobid

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_is_complete(self, jobid):
        log.debug('LocalRPC.job.is_complete %s' % (jobid))
        job = self.job_queue.getJob(jobid)
        return job.isComplete()

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_is_running(self, jobid):
        log.debug('LocalRPC.job.is_running %s' % (jobid))
        job = self.job_queue.getJob(jobid)
        return not job.isComplete()

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_get_result(self, jobid, remove_if_complete = False):
        log.debug('LocalRPC.job.get_result %s' % (jobid))
        job = self.job_queue.getJob(jobid)
        if not job.isComplete():
            return False
        if remove_if_complete:
            self.job_queue.removeJob(jobid)
        print job.result
        return job.result

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_remove(self, jobid):
        log.debug('LocalRPC.job.remove %s' % (jobid))
        self.job_queue.removeJob(jobid)
        return True

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_list(self):
        log.debug('LocalRPC.job.list called')
        result = []
        for job in self.job_queue.iterJobs():
            jobinfo = {}
            jobinfo['complete'] = job.isComplete()
            jobinfo['jobid'] = job.jobid
            jobinfo['runtime'] = job.runTime()
            jobinfo['name'] = job.name
            jobinfo['args'] = job.args
            result.append(jobinfo)
        return result

    @helpers.error_handler
    @helpers.encode_str_args
    def xmlrpc_statistics(self):
        log.debug('LocalRPC.job.statistics called')
        ret = {}
        ret['total number of jobs'] = 0
        ret['running jobs'] = 0
        ret['completed jobs still in queue'] = 0
        for job in self.job_queue.iterJobs():
            ret['total number of jobs'] += 1
            if job.isComplete():
                ret['completed jobs still in queue'] += 1
            else:
                ret['running jobs'] += 1
        return ret

    @helpers.error_handler
    @helpers.encode_str_args
    @defer.inlineCallbacks
    def xmlrpc_quickrun(self, jobtype, jobargs):
        log.msg('LocalRPC.quickrun (%s)' % (jobtype))
        jobid = str(uuid.uuid1())
        try:
            job = self.job_queue.runJob(jobid, jobtype, jobargs)
        except Exception, e:
            defer.returnValue({})
        self.job_queue.removeJob(jobid)
        while True:
            if job.isComplete():
                break
            yield utils.d_sleep(1)
        defer.returnValue(job.result)

def make_rpc_service(job_queue, listen_port = DEFAULT_PORT):
    root_rpc = RootRPC()
    xmlrpc.addIntrospection(root_rpc)

    job_rpc = JobRPC(job_queue)
    root_rpc.putSubHandler('job', job_rpc)

    service = internet.TCPServer(listen_port, server.Site(root_rpc))
    log.msg('Created local listener service listening on port %d.' % (
        listen_port))

    return service

