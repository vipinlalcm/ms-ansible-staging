import json

from twisted.internet import reactor
from twisted.web.client import Agent
from twisted.web.http_headers import Headers
from zope.interface import implements
from twisted.internet.defer import succeed
from twisted.web.iweb import IBodyProducer
from twisted.internet import defer

from hlprobelib import errors

from hlprobelib import log
from hlprobelib import recurringtask


class HeartbeatProducer(object):
    implements(IBodyProducer)

    def __init__(self):
        self.body = '{"value": true}'
        self.length = len(self.body)

    def startProducing(self, consumer):
        consumer.write(self.body)
        return succeed(None)

    def pauseProducing(self):
        pass

    def stopProducing(self):
        pass


class HeartbeatTask(recurringtask.RecurringTask):
    interval = 120

    def __init__(self, monitor_id, api_key, api_server = 'api.monitorscout.com'):
        super(HeartbeatTask, self).__init__()
        self.url = 'http://%s/1.0/monitors/passive/%s/report' % (api_server, monitor_id)
        self.headers = Headers({
            'X-Auth-API-Key': [api_key],
            'Content-Type': ['application/json']
        })
        self.producer = HeartbeatProducer()

    @defer.inlineCallbacks
    def _run(self):
        agent = Agent(reactor)
        try:
            yield agent.request('PUT', self.url, self.headers, self.producer)
        except Exception, e:
            log.msg('Failed to report heartbeat: %s' % (str(e)))
        else:
            log.debug('Heartbeat report successful.')
