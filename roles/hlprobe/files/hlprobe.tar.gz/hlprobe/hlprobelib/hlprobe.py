from optparse import OptionParser
import time
import os
import os.path
import sys

import json

from twisted.application import service, app
from twisted.internet import reactor
from twisted.internet import defer
import twisted.internet.utils

import hlprobelib.external
hlprobelib.external.auto_detect()

from hlprobelib import errors
from hlprobelib import localrpc
from hlprobelib import jobqueue
from hlprobelib import jobmanager

from hlprobelib import log
from hlprobelib import rpcclient
from hlprobelib import recurringtask
from hlprobelib import utils
from hlprobelib import connectivity
from hlprobelib import memorylogger
from hlprobelib import threadlogger
from hlprobelib import hlapp
from hlprobelib import dpbridge
from hlprobelib import heartbeat


def import_external_jobs(job_dir):
    if not job_dir:
        return
    job_dir = os.path.abspath(job_dir)
    if not os.path.isdir(job_dir):
        raise Exception('unable to load external jobs, invalid path')
    sys.path.append(job_dir)
    for module in os.listdir(job_dir):
        if not os.path.isfile(os.path.join(job_dir, module)):
            continue
        if not module.endswith('.py'):
            continue
        if len(module) < 4:
            continue
        __import__(module[:-3])

def run_hlprobe(argv):
    """Start everything up."""
    conf, options, args = hlapp.run_default_setup(argv)

    section = conf.section('CONNECTIVITYCHECKER')
    fping_path = section.get('fping-path', error_if_missing = False)
    if fping_path:
        connectivity.set_fping_path(fping_path)
    connectivity_checker = connectivity.ConnectivityChecker(
            section.get('check-hosts', error_if_missing = False))
    reactor.callWhenRunning(connectivity_checker.start)

    section = conf.section('DEFAULT')
    probe_id = section.get('probe-id', error_if_missing = True)
    probe_key = section.get('probe-key', error_if_missing = True)
    dpbridge_hostname = section.get('dpbridge-hostname', error_if_missing = False) or 'dpbridge.monitorscout.com'
    dpbridge_port = section.getInt('dpbridge-port', error_if_missing = False) or 22101
    monitor_binary_paths = section.get('monitor-binary-paths', error_if_missing = False)
    if monitor_binary_paths:
        utils.DEFAULT_MONITOR_BINARY_PATHS += monitor_binary_paths.split(':')
    # Import all the builtin jobs, but only after utils.DEFAULT_MONITOR_BINARY_PATHS has been updated.
    import hlprobelib.jobs.locals
    import_external_jobs(section.get('external-job-dir', error_if_missing = False))
    section = conf.section('JOBQUEUE')
    job_queue = jobqueue.JobQueue(
            section.getInt('max-threads', error_if_missing = True))
    dpbridge_client = dpbridge.DPBridgeClient(dpbridge_hostname, dpbridge_port, probe_id, probe_key)
    job_manager = jobmanager.JobManager(dpbridge_client, job_queue, connectivity_checker)
    reactor.callWhenRunning(job_manager.start)

    section = conf.section('HEARTBEAT')
    if section:
        probe_monitor_id = section.get('probe-monitor-id', error_if_missing = False)
        probe_monitor_api_key = section.get('probe-monitor-api-key', error_if_missing = False)
        probe_api_server = section.get('probe-api-server', error_if_missing = False) or 'api.monitorscout.com'
        if probe_monitor_id and probe_monitor_api_key:
            heartbeat_task = heartbeat.HeartbeatTask(probe_monitor_id, probe_monitor_api_key, probe_api_server)
            reactor.callWhenRunning(heartbeat_task.start)
        else:
            log.msg('Skipping heartbeat process, probe-monitor-id or probe-monitor-api-key not set')

    memorylogger.run_memory_logger(10)
    threadlogger.run_thread_logger(10)

    section = conf.section('LOCALRPC')
    local_rpc = localrpc.make_rpc_service(
            job_queue,
            section.getInt('port', error_if_missing = True))

    application = hlapp.create_app('hlprobe', [local_rpc])
    hlapp.startup(conf, options, application)

def main(argv):
    """Main worker entry point.

    This is mostly just an exception wrapper for run_worker.
    """
    try:
        return run_hlprobe(argv[1:])
    except errors.HLProbeError, e:
        print 'ERROR:', e
