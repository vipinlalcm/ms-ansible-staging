import os

GEOIP_DATAFILES = [
   '/opt/local/share/GeoIP/GeoIP.dat',
   '/usr/share/GeoIP/GeoIP.dat'
]
GEOIP_DATAFILE = None
GEOIP_DB = None
try:
    import GeoIP
    for _dt in GEOIP_DATAFILES:
        if os.path.isfile(_dt):
            GEOIP_DATAFILE = _dt
            break
    if not GEOIP_DATAFILE:
        print 'ERROR: missing GeoIP data file, related functions will not work.'
except ImportError:
    print 'ERROR: missing GeoIP module, related functions will not work.'

from hlprobelib import errors

def get_geoip_instance():
    global GEOIP_DB
    if not GEOIP_DATAFILE:
        raise errors.HLProbeError('GeoIP functions not available')
    GEOIP_DB = GeoIP.open(GEOIP_DATAFILE, GeoIP.GEOIP_STANDARD)
    return GEOIP_DB

def country_code_by_ip(addr):
    gi = get_geoip_instance()
    return gi.country_code_by_addr(addr)

def country_name_by_ip(addr):
    gi = get_geoip_instance()
    cc = gi.country_code_by_addr(addr)
    ret = None
    if cc:
        ret = country_name_by_code(cc)
    return ret

def country_name_by_code(country_code):
    return GeoIP.country_names.get(country_code, None)

def is_valid_country_code(country_code):
    return country_code in GeoIP.country_names
