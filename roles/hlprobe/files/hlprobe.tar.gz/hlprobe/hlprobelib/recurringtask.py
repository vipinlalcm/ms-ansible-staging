import time
from twisted.internet import reactor, defer

from hlprobelib import log
from hlprobelib import errors

class RecurringTask(object):
    interval = None

    def _rt_init(self):
        if self.interval is None:
            raise errors.RecurringTaskError('no interval specificed for RecurringTask')
        self._rt_last_run_timestamp = 0
        self._rt_started = False
        self._rt_current_run_start = 0
        self._rt_start_running = False
        self._rt_start_defer = None
        self._rt_main_running = False
        self._rt_main_defer = None
        self._rt_mainloop_dc = None
        self._rt_init_called = True
        self._rt_watchdog_dc = None
        self.running = False
        self.paused = False
        self.startup_complete = False

    def start(self):
        if not getattr(self, '_rt_init_called', False):
            self._rt_init()
        if self._rt_started:
            raise errors.RecurringTaskError('start already called')
        self._rt_watchdog()
        self._rt_started = True
        self.running = True
        try:
            log.debug('RecurringTask %s starting' % (self))
            self._rt_start_defer = self._start()
        except Exception, e:
            log.msg('RecurringTask "%s" startup failed: %s' % (self, e))
        else:
            self._rt_start_running = True
            self._rt_start_defer.addCallbacks(self._rt_cbStart, self._rt_ebStart)
        return self._rt_start_defer

    def _start(self):
        """Should be overriden in subclass."""
        return defer.succeed(True)

    def _run(self):
        """Should be overriden in subclass."""
        return defer.succeed(True)

    def _rt_cbStart(self, result):
        self._rt_start_running = False
        self.startup_complete = True
        self._rt_mainloop()

    def _rt_ebStart(self, error):
        log.msg('RecurringTask "%s" startup failed: %s' % (self, error))
        self._rt_start_running = False
        self.running = False

    @defer.inlineCallbacks
    def shutdown(self, wait = False):
        self.running = False
        if self._rt_mainloop_dc:
            self._rt_mainloop_dc.cancel()
        if self._rt_watchdog_dc:
            self._rt_watchdog_dc.cancel()
        ret = yield self._stop()
        if wait:
            yield self.wait()
        defer.returnValue(ret)
    stop = shutdown

    def _stop(self):
        """Should be overriden in subclass."""
        return defer.succeed(True)

    def pause(self):
        self.paused = True

    def unpause(self):
        self.paused = False

    @defer.inlineCallbacks
    def wait(self):
        """Wait until the task is not performing any action."""
        if self._rt_start_running:
            yield self._rt_start_defer
        elif self._rt_main_running:
            yield self._rt_main_defer
        defer.returnValue(True)

    def _rt_now(self):
        return int(time.time())

    def _rt_runtime(self):
        return self._rt_now() - self._rt_current_run_start

    def _rt_watchdog(self, *args, **kwargs):
        if self._rt_main_running and self._rt_runtime() > 30:
            log.debug('RecurringTask "%s" has been running for %s seconds' % (self, self._rt_runtime()))
        self._rt_watchdog_dc = reactor.callLater(10, self._rt_watchdog)

    def _rt_mainloop(self, *args, **kwargs):
        self._rt_mainloop_dc = None
        if not self.running:
            return
        if self.paused:
            return self._rt_scheduleNextRun()
        try:
#            log.debug('RecurringTask "%s" running' % (self))
            self._rt_main_defer = self._run(*args, **kwargs)
        except Exception, e:
            log.msg('RecurringTask "%s" _run raised exception: %s' % (self, e))
            log.debug(traceback.format_exc())
            self._rt_scheduleNextRun()
        else:
            self._rt_main_running = True
            self._rt_current_run_start = self._rt_now()
            self._rt_main_defer.addCallbacks(self._rt_cbRun, self._rt_ebRun)

    def _rt_cbRun(self, result):
        self._rt_last_run_timestamp = self._rt_now()
        self._rt_main_running = False
        self._rt_scheduleNextRun()

    def _rt_ebRun(self, error):
        log.msg('RecurringTask "%s" _run returned error: %s' % (self, error))
        self._rt_last_run_timestamp = self._rt_now()
        self._rt_main_running = False
        self._rt_scheduleNextRun()

    def _rt_scheduleNextRun(self):
        # Avoid scheduling new calls if we've been stopped.
        if self.running:
            self._rt_mainloop_dc = reactor.callLater(self.interval, self._rt_mainloop)
