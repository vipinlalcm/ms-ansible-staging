"""Configures logging.

Uses twisted logging.
"""
import sys
import os
import os.path

from twisted.python import log, syslog, logfile

_debug_logging = False
_include_sections = None
_logging_configured = False

def configure_logging(logfilename = '-', debug_logging = False,
        include_sections = None, rotate_length = 1000000,
                     max_rotated_files = 250):
    global _debug_logging
    global _include_sections
    global _logging_configured
    if rotate_length is None:
        rotate_length = 1000000
    if max_rotated_files is None:
        max_rotated_files = 250
    _logging_configured = True
    _debug_logging = debug_logging
    _include_sections = include_sections
    observer = None
    if logfilename == '-':
        logfd = sys.stdout
    else:
        logpath = os.path.split(logfilename)[0]
        if not os.path.exists(logpath):
            os.makedirs(logpath)
        logfd = logfile.LogFile.fromFullPath(logfilename, rotateLength=rotate_length, maxRotatedFiles=max_rotated_files)
    observer = log.FileLogObserver(logfd).emit
    log.startLoggingWithObserver(observer)
    sys.stdout.flush()

def msg(logmsg, section = 'default'):
    global _include_sections
    global _logging_configured
    if not _logging_configured:
        configure_logging()
    if _include_sections is not None and section not in _include_sections:
        return
    logmsg = '[%s] %s' % (section, logmsg)
    log.msg(logmsg)
err = msg

def debug(logmsg, section = 'default'):
    global _debug_logging
    if not _debug_logging:
        return
    global _logging_configured
    if not _logging_configured:
        configure_logging()
    logmsg = '[DEBUG] %s' % (logmsg)
    return msg(logmsg, section)
