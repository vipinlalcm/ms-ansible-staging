import socket
from StringIO import StringIO
import re

from twisted.internet import reactor, protocol, defer, ssl
from twisted.protocols import policies, ftp

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class FTPMonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [bool],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-ftp'

    def _run(self, hostname, timeout, port, use_ssl=False,
             username='', password=''):
        log.debug('%s._run starting _run.' % (self))
        if len(username) == 0:
            username = None
            password = None
        d = run_ftpmonitor(hostname, port, username, password, use_ssl,
                           timeout)
        d.addCallbacks(self._cbMonitor, self._ebMonitor)

    def _cbMonitor(self, msg):
        log.debug('FTPMonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('FTPMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()


registry.job_registry.register(FTPMonitorJob)


def run_ftpmonitor(hostname, port, username, password, use_ssl,
                   timeout):
    d = defer.Deferred()
    factory = _FTPMonitorFactory(d, timeout,
                                 username, password)
    if use_ssl:
        context = ssl.ClientContextFactory()
        reactor.connectSSL(hostname, port, factory,
                           context, timeout=timeout)
    else:
        reactor.connectTCP(hostname, port, factory,
                           timeout=timeout)
    return d


class _FTPMonitorFactory(protocol.ClientFactory):
    def __init__(self, deferred, timeout,
                 username, password):
        self.deferred = deferred
        self.timeout = timeout
        self.username = username
        if self.username:
            self.username = self.username.encode('utf-8')
        self.password = password
        if self.password:
            self.password = self.password.encode('utf-8')

    # connector.stopConnecting() can be used to stop the connection attempt.
    def startedConnecting(self, connector):
        pass

    def buildProtocol(self, addr):
        proto = _FTPMonitorProtocol(self, self.username, self.password)
        return proto

    def clientConnectionFailed(self, connector, reason):
        self.deferred.errback(reason)


class _FTPMonitorProtocol(ftp.FTPClientBasic):
    def __init__(self, factory, username, password):
        ftp.FTPClientBasic.__init__(self)
        self._factory = factory
        self._username = username
        self._password = password
        self._error = None
        self._check_ok = False
        self._hard_timeout = reactor.callLater(
            self._factory.timeout + 1, self._hardTimeout)
        self.doLogin()

    def doLogin(self):
        if self._username:
            ftp.FTPClientBasic.queueLogin(self, self._username, self._password)
        d = self.quit()
        d.addCallbacks(self._cbQuit, self.fail)

    def _cbQuit(self, *args, **kwargs):
        self._check_ok = True
        self.transport.loseConnection()

    def fail(self, error):
        self.setError(str(error.value))
        if self.transport:
            self.transport.loseConnection()
        self._fail(error)

    def sendLine(self, line):
    #        log.debug('send: %s' % (line))
        ftp.FTPClientBasic.sendLine(self, line)

    def lineReceived(self, line):
    #        log.debug('recv: %s' % (line))
        ftp.FTPClientBasic.lineReceived(self, line)

    def connectionLost(self, reason):
        ftp.FTPClientBasic.connectionLost(self, reason)
        if not self._check_ok:
            self.setError('Invalid response from server')
        if self._hard_timeout:
            self._hard_timeout.cancel()
        if self._error:
            self._factory.deferred.errback(self._error)
        else:
            self._factory.deferred.callback('')

    def setError(self, error):
        if self._error is None:
            if type(error) is str:
                self._error = errors.HLProbeError(error)
            else:
                self._error = error

    def _hardTimeout(self, *args, **kwargs):
        self.setError('Timeout, session took to long')
        self._hard_timeout = None
        if self.transport:
            self.transport.loseConnection()
        try:
            self._fail('timeout')
        except:
            pass

    def quit(self):
        return self.queueStringCommand('QUIT')

