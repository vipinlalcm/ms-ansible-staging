import time
import threading

from hlprobelib import errors
from hlprobelib import utils
from hlprobelib import log


class ErrorJob(object):
    """Error job placeholder.
    
    Use as a placeholder for a job that is so broken it failed to
    create a proper job instance.
    """
    name = 'error-job'

    def __init__(self, queue, delegator_id, jobid, error, *args):
        self.queue = queue
        self.delegator_id = delegator_id
        self.jobid = jobid
        log.debug('%s.__init__ created new error job.' % (self))
        log.debug('%s.__init__ job args: %s' % (self, str(args)))
        self.args = args
        self.completed = True
        self._lock = threading.Lock()
        self.created_time = time.time()
        self.started_time = time.time()
        self.completed_time = time.time()
        self.result = {
            'status': 'failure',
            'errormsg': error or '',
            'runtime': 0,
        }

    def __str__(self):
        return '<Job "%s" id:%s>' % (self.__class__.__name__, self.jobid)

    def lock(self):
        self._lock.acquire()

    def unlock(self):
        self._lock.release()

    @utils.with_lock
    def setComplete(self, status='failure'):
        self.queue.jobComplete(self)

    @utils.with_lock
    def isComplete(self):
        return self.completed

    @utils.with_lock
    def runTime(self):
        return self.result['runtime']

    def _run(self):
        pass

    def run(self):
        pass

    def _validateArgs(self):
        pass
