from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosMSSQLMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-mssql-nagios'
    executable = utils.get_monitor_binary('check_mssql_monitor')

    def _run(self, hostname, timeout, port, username, password):
        log.debug('%s._run starting _run.' % (self))
        args = self._makeDefaultArgs(hostname)
        if port:
            self._addArg(args, '-p', port)
        if username:
            self._addArg(args, '-U', username)
        if password:
            self._addArg(args, '-P', password)
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosMSSQLMonitorJob)
