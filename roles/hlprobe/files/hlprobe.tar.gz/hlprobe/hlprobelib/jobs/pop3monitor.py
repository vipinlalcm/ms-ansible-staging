import socket
from StringIO import StringIO
import re

from twisted.internet import reactor, protocol, defer, ssl
from twisted.protocols import policies
from twisted.mail import pop3

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class POP3MonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [bool],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [bool],
        [bool]]
    name = 'monitor-pop3'

    def _run(self, hostname, timeout, port, use_ssl=False,
             username='', password='',
             fetch_matching_message='',
             remove_matching_message=False,
             clear_mailbox=False):
        log.debug('%s._run starting _run.' % (self))
        if len(username) == 0:
            username = None
            password = None
        if len(fetch_matching_message) == 0:
            fetch_matching_message = None
        d = run_pop3monitor(hostname, port, username, password, use_ssl,
                            fetch_matching_message, remove_matching_message,
                            clear_mailbox, timeout)
        d.addCallbacks(self._cbMonitor, self._ebMonitor)

    def _cbMonitor(self, msg):
        log.debug('POP3MonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('POP3MonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = self._parseGenericErrors(e)
        self.setFailure()


registry.job_registry.register(POP3MonitorJob)


def run_pop3monitor(hostname, port, username, password, use_ssl,
                    fetch_matching_message, remove_matching_message,
                    clear_mailbox, timeout):
    d = defer.Deferred()
    factory = _POP3MonitorFactory(d, timeout,
                                  username, password, fetch_matching_message,
                                  remove_matching_message,
                                  clear_mailbox)
    if use_ssl:
        context = ssl.ClientContextFactory()
        reactor.connectSSL(hostname, port, factory,
                           context, timeout=timeout)
    else:
        reactor.connectTCP(hostname, port, factory,
                           timeout=timeout)

    return d


class _POP3MonitorFactory(protocol.ClientFactory):
    def __init__(self, deferred, timeout,
                 username, password, fetch_matching_message,
                 remove_matching_message,
                 clear_mailbox):
        self.deferred = deferred
        self.timeout = timeout
        self.username = username
        if self.username:
            self.username = self.username.encode('utf-8')
        self.password = password
        if self.password:
            self.password = self.password.encode('utf-8')
        self.fetch_matching_message = fetch_matching_message
        if self.fetch_matching_message:
            self.fetch_matching_message = self.fetch_matching_message.encode('utf-8')
        self.remove_matching_message = remove_matching_message
        self.clear_mailbox = clear_mailbox

    # connector.stopConnecting() can be used to stop the connection attempt.
    def startedConnecting(self, connector):
        pass

    def buildProtocol(self, addr):
        proto = _POP3MonitorProtocol(self,
                                     self.username, self.password,
                                     self.fetch_matching_message,
                                     self.remove_matching_message,
                                     self.clear_mailbox)
        return proto

    def clientConnectionFailed(self, connector, reason):
        self.deferred.errback(reason)


class _POP3MonitorProtocol(pop3.AdvancedPOP3Client):
    timeout = 10
    allowInsecureLogin = True
    # Max size of messages we fetch for fetch_matching_message test.
    max_fetch_size = 100000

    def __init__(self, factory, username, password,
                 fetch_matching_message,
                 remove_matching_message,
                 clear_mailbox):
        """Protocol for monitoring a pop3 server.

            username:
                The username to used to login or '' for no login.
            password:
                The password used to login.
            fetch_matching_message:
                After login, check if there is a message matching the
                given regexp. If set to '' this check will be skipped.
            remove_matching_message:
                Remove the message matched by remove_matching_message
                if set to True.
            clear_mailbox:
                Clear the entire mailbox if set to True.
        """
        self._factory = factory
        self._username = username
        self._password = password
        if fetch_matching_message:
            self._fetch_matching_message = re.compile(fetch_matching_message)
        else:
            self._fetch_matching_message = None
        self._remove_matching_message = remove_matching_message
        self._clear_mailbox = clear_mailbox
        self._error = None
        self._check_ok = False
        # pop3.AdvancedPOP3Client will keep reseting the timeout from
        # policies.TimeoutMixin as long
        # as it keeps getting valid responses from the server.
        # This could keep our session going for longer than
        # we really want, so we keep a seperate hard timeout
        # that will kill the session regardless of smtp activity.
        self._hard_timeout = reactor.callLater(
            self._factory.timeout + 1, self._hardTimeout)
        self.setTimeout(self._factory.timeout)

    def sendLine(self, line):
        #log.debug('send: %s' % (line))
        pop3.AdvancedPOP3Client.sendLine(self, line)

    def lineReceived(self, line):
        #log.debug('recv: %s' % (line))
        pop3.AdvancedPOP3Client.lineReceived(self, line)

    def connectionLost(self, reason):
        pop3.AdvancedPOP3Client.connectionLost(self, reason)
        if not self._check_ok:
            self.setError('Invalid response from server')
        if self._hard_timeout:
            self._hard_timeout.cancel()
        if self._error:
            self._factory.deferred.errback(self._error)
        else:
            self._factory.deferred.callback('')
        self._factory = None

    def setError(self, error):
        if self._error is None:
            if type(error) is str:
                self._error = errors.HLProbeError(error)
            else:
                self._error = error

    def _hardTimeout(self, *args, **kwargs):
        self.setError('Timeout, session took to long')
        self._hard_timeout = None
        self.transport.loseConnection()

    def timeoutConnection(self):
        pop3.AdvancedPOP3Client.timeoutConnection(self)
        self.setError('Timeout, session took to long')

    def serverGreeting(self, greeting):
        # If we have no username, just quit.
        if self._username:
            d = self.login(self._username, self._password)
            d.addCallbacks(self._cbLogin, self._ebGeneric)
        else:
            self._check_ok = True
            self.quit()

    def _cbLogin(self, *args, **kwargs):
        if self._fetch_matching_message:
            self.fetchMatchingMessage()
        else:
            self._check_ok = True
            self.quit()

    def _ebGeneric(self, e):
        self.setError(str(e.value))
        self.quit()

    def fetchMatchingMessage(self):
        d = self.listSize()
        d.addCallbacks(self.fetchMatchingMessage_sizes, self._ebGeneric)

    def fetchMatchingMessage_sizes(self, sizes):
        self._retr_messages = []
        for pos, size in enumerate(sizes):
            if size is not None and size <= self.max_fetch_size:
                self._retr_messages.append(pos)
        self.fetchMatchingMessage_fetch()

    def fetchMatchingMessage_fetch(self):
        if len(self._retr_messages) == 0:
            self.setError('Matching message not found on pop3 server')
            if self._clear_mailbox:
                self.clearMailbox()
            else:
                self.quit()
        else:
            index = self._retr_messages.pop(0)
            d = self.retrieve(index)
            d.addCallbacks(self.fetchMatchingMessage_gotmessage, self._ebGeneric,
                           callbackArgs=(index,))

    def fetchMatchingMessage_gotmessage(self, message, index):
        matched = False
        for line in message:
            if self._fetch_matching_message.search(line):
                matched = True
                break
        if matched:
            self._check_ok = True
            if self._clear_mailbox:
                self.clearMailbox()
            elif self._remove_matching_message:
                d = self.delete(index)
                d.addCallbacks(self.fetchMatchingMessage_removedmessage,
                               self._ebGeneric)
            else:
                self.quit()
        else:
            self.fetchMatchingMessage_fetch()

    def fetchMatchingMessage_removedmessage(self, msg):
        if self._clear_mailbox:
            self.clearMailbox()
        else:
            self.quit()

    def clearMailbox(self):
        d = self.stat()
        d.addCallbacks(self.clearMailbox_stat, self._ebGeneric)

    def clearMailbox_stat(self, result):
        num_messages, size = result
        self._clear_mailbox_pos = 0
        self._clear_mailbox_num_messages = num_messages
        self.clearMailbox_delete('')

    def clearMailbox_delete(self, msg):
        if self._clear_mailbox_pos < self._clear_mailbox_num_messages:
            d = self.delete(self._clear_mailbox_pos)
            d.addCallbacks(self.clearMailbox_delete, self._ebGeneric)
            self._clear_mailbox_pos += 1
        else:
            self.quit()

