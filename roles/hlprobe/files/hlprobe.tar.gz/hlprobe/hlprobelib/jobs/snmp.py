import time
from twisted.internet import defer
from pynetsnmp.twistedsnmp import AgentProxy, asOidStr, asOid
import pynetsnmp.netsnmp
import twisted.names

from hlprobelib import errors
from hlprobelib import log


class SNMPWalker(object):
    default_attempts = 3

    def __init__(self, hostname, port, version, auth_info, timeout, attempts=3):
        if version in [3, '3']:
            version = '2c'
        self.hostname = hostname
        self.port = port
        self.version = version
        self.auth_info = auth_info
        self.full_timeout = timeout
        self.attempts = attempts
        self.timeout = float(timeout) / self.attempts + 1
        self.hostname = hostname
        self.port = port
        self.version = version
        self.auth_info = auth_info
        self.proxy = None

    @defer.inlineCallbacks
    def getProxy(self):
        if self.proxy:
            defer.returnValue(self.proxy)
        try:
            self.hostname = yield twisted.names.client.getHostByName(self.hostname)
        except:
            pass
        try:
            self.proxy = self._makeProxy(self.hostname, self.port, self.version, self.auth_info)
        except pynetsnmp.netsnmp.ArgumentParseError, e:
            log.msg('Error creating snmp proxy: %s' % (str(e)))
            raise errors.SNMPError('snmp argument parse error')
        except Exception, e:
            log.msg('Error creating snmp proxy: %s' % (str(e)))
            raise errors.SNMPError(str(e))
        defer.returnValue(self.proxy)

    def _makeProxy(self, hostname, port, version, auth_info):
        if version in [1, 2, '1', '2', '2c']:
            if 'community' not in auth_info:
                raise errors.InvalidSNMPAuthInfo('missing community')
            proxy = AgentProxy(ip=hostname,
                               port=port,
                               snmpVersion=version,
                               protocol=None,
                               allowCache=False,
                               community=auth_info['community'],
                               timeout=self.timeout,
                               tries=self.attempts)
        elif version in [3, '3']:
            v3_args = self._parseV3Args(auth_info)
            proxy = AgentProxy(ip=hostname,
                               port=port,
                               snmpVersion=version,
                               protocol=None,
                               allowCache=False,
                               community='',
                               cmdLineArgs=v3_args,
                               timeout=self.timeout,
                               tries=self.attempts)
        else:
            raise errors.InvalidSNMPAuthInfo('invalid snmp version')
        proxy.open()
        return proxy

    def _getV3Arg(self, auth_info, arg):
        if arg not in auth_info:
            raise errors.InvalidSNMPAuthInfo('missing %s' % (arg))
        return auth_info[arg]

    def _parseV3Args(self, auth_info):
        dict_args = {'-a': self._getV3Arg(auth_info, 'auth_proto'), '-A': self._getV3Arg(auth_info, 'auth_pass'),
                     '-l': self._getV3Arg(auth_info, 'sec_level'), '-x': self._getV3Arg(auth_info, 'priv_proto'),
                     '-X': self._getV3Arg(auth_info, 'priv_pass'), '-u': self._getV3Arg(auth_info, 'sec_name')}
        args = []
        for key, value in dict_args.iteritems():
            args.append(key)
            args.append(value)
        return args

    @defer.inlineCallbacks
    def get(self, oids):
        proxy = yield self.getProxy()
        if type(oids) != list:
            oids = [oids]
        ret = yield self.proxy.get(oids)
        defer.returnValue(ret)

    @defer.inlineCallbacks
    def walk(self, oids):
        proxy = yield self.getProxy()
        w = _SNMPWalk(self, oids, self.full_timeout)
        ret = yield w.walk()
        defer.returnValue(ret)

    def close(self):
        try:
            if self.proxy:
                self.proxy.close()
        except:
            pass


class _SNMPWalk(object):
    max_oids = 100000

    def __init__(self, walker, oids, timeout=600):
        self.walker = walker
        self.proxy = walker.proxy
        if type(oids) != list:
            oids = [oids]
        self.oids = [asOid(oid) for oid in oids]
        self.oid_count = 0
        self.timeout = timeout

    def walk(self):
        if self.walker.version in [1, '1']:
            self._walk_func = self.proxy._walk
        else:
            def _w(oids):
                return self.proxy._getbulk(0, 10, [oids])

            self._walk_func = _w
        return self._walk()

    @defer.inlineCallbacks
    def _walk(self):
        ret = {}
        self.start = time.time()
        while self.oids:
            start_oid = current_oid = self.oids.pop()
            prev_oid = None
            current_result = {}
            ret[asOidStr(current_oid)] = current_result
            while current_oid:
                self._checkLimits()
                result = yield self._walk_func(current_oid)
                current_oid = None
                if result:
                    for oid, value in result:
                        self.oid_count += 1
                        if oid[:len(start_oid)] == start_oid and oid > start_oid:
                            if prev_oid and oid <= prev_oid:
                                break
                            prev_oid = oid
                            current_result[asOidStr(oid)] = value
                            current_oid = oid
                        else:
                            break
                else:
                    break
        defer.returnValue(ret)

    def _checkLimits(self):
        runtime = time.time() - self.start
        if runtime > self.timeout:
            log.debug('%s aborting SNMP walk due to timeout (oidcount: %s)' % (self, self.oid_count))
            raise Exception('timeout, server responding to slowly')
            # Keep the result a reasonable amount.
        if self.oid_count > self.max_oids:
            log.debug('%s aborting SNMP walk due to do many oids (oidcount: %s)' % (self, self.oid_count))
            raise Exception('oid count exceeeded')
