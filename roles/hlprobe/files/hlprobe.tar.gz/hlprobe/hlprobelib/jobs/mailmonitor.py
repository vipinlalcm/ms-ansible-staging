import socket
import random
import sha
import time

from twisted.internet import reactor, protocol, defer, ssl
from twisted.protocols import policies
from twisted.mail import smtp

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import smtpmonitor
from hlprobelib.jobs import pop3monitor
from hlprobelib import errors
from hlprobelib import log


class MailMonitorJob(base.Job):
    """Monitor mail message delivery.

    Sends a message via an smtp server and checks that it arrives at
    it's destination (via pop3 or imap).
    """
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [int],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [bool],
        [bool]
    ]
    name = 'monitor-mail'

    _retr_interval = 10
    _mail_from = 'hlprobe@example.com'

    def _run(self, smtp_server, timeout, smtp_port, pop3_server, pop3_port,
             mail_to, pop3_username, pop3_password,
             remove_matching_message,
             clear_mailbox):
        log.debug('%s._run starting _run.' % (self))
        self._smtp_server = smtp_server
        self._smtp_port = smtp_port
        self._pop3_server = pop3_server
        if len(self._pop3_server) == 0:
            self._pop3_server = self._smtp_server
        self._pop3_port = pop3_port
        self._mail_to = mail_to.encode('utf-8')
        self._pop3_username = pop3_username.encode('utf-8')
        self._pop3_password = pop3_password.encode('utf-8')
        self._remove_matching_message = remove_matching_message
        self._clear_mailbox = clear_mailbox
        self._timeout = timeout
        self._message_id = self._makeMessageID()
        self._start_time = time.time()
        self._sendMessage()

    def _makeMessageID(self):
        shasum = sha.new()
        shasum.update(str(time.time()))
        shasum.update(str(random.getrandbits(128)))
        return shasum.hexdigest()

    def _makeMessage(self):
        msg = ['From: %s' % (self._mail_from), 'To: %s' % (self._mail_to), 'Subject: hlprobe mail monitor test message',
               'X-HLProbe-ID: %s' % (self._message_id)]
        return '\n'.join(msg)

    def _sendMessage(self):
        d = smtpmonitor.run_smtpmonitor(self._smtp_server,
                                        self._smtp_port,
                                        self._mail_from,
                                        self._mail_to,
                                        use_ssl=False,
                                        use_tls=False,
                                        use_auth=False,
                                        username=None,
                                        secret=None,
                                        timeout=self._timeRemaining(),
                                        message=self._makeMessage())
        d.addCallbacks(self._cbSend, self._ebMonitor)

    def _cbSend(self, msg):
        log.debug('MailMonitorJob._cbSend: success')
        self._recvMessage()

    def _recvMessage(self):
        d = pop3monitor.run_pop3monitor(self._pop3_server,
                                        self._pop3_port,
                                        self._pop3_username,
                                        self._pop3_password,
                                        False,
                                        '^X-HLProbe-ID: %s$' % (self._message_id),
                                        remove_matching_message=self._remove_matching_message,
                                        clear_mailbox=self._clear_mailbox,
                                        timeout=self._timeRemaining())
        d.addCallbacks(self._cbRecv, self._ebRecv)

    def _cbRecv(self, msg):
        log.debug('MailMonitorJob._cbRecv: success')
        self.setSuccess()

    def _ebRecv(self, e):
        if self._timeRemaining() < self._retr_interval:
            log.debug('MailMonitorJob._ebRecv, job failed')
            self.result['errormsg'] = self._parseGenericErrors(e)
            self.setFailure()
        else:
            log.debug('MailMonitorJob._ebRecv, trying again (%s)' % (str(e.value)))
            reactor.callLater(self._retr_interval, self._recvMessage)

    def _ebMonitor(self, e):
        log.debug('MailMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = self._parseGenericErrors(e)
        self.setFailure()

    def _timeRemaining(self):
        ret = self._timeout - (time.time() - self._start_time)
        if ret < 0:
            ret = 0
        return ret


registry.job_registry.register(MailMonitorJob)

