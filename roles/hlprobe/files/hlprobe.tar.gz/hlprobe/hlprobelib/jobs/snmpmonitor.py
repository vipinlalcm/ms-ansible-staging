from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import snmp
from hlprobelib import errors
from hlprobelib import log


class SNMPMonitorJob(base.Job):
    """This is a plain old snmp monitor.

    It checks if a snmp server seems to be working. It can not fetch specific
    oids or anything like that, use the snmpget/snmpwalk monitors for that.
    This is just used to check if a snmp server is alive.
    """
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode, int],
        [dict],
        [str]]
    name = 'snmp-monitor'

    def _run(self, hostname, timeout, port, version, auth_info, oid='.1.3.6.1.2.1.1.1.0'):
        log.debug('%s._run starting _run.' % (self))
        self.walker = None
        try:
            self.walker = snmp.SNMPWalker(hostname, port, version, auth_info,
                                          timeout)
            d = self.walker.get([oid])
            d.addCallbacks(self._cbGet, self._ebGet)
        except Exception, e:
            log.debug('SNMPMonitorJob._run error: %s(%s)' % (type(e), e))
            self.result['errormsg'] = str(e)
            self.setFailure()
            if self.walker:
                self.walker.close()

    def _cbGet(self, result):
        log.debug('SNMPMonitorJob._cbGet: success')
        self.result['response'] = result
        # self.setMetric('response time', self.result['runtime'])
        self.setSuccess()
        self.walker.close()

    def _ebGet(self, e):
        log.debug('SNMPMonitorJob._ebGet: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()
        self.walker.close()


registry.job_registry.register(SNMPMonitorJob)
