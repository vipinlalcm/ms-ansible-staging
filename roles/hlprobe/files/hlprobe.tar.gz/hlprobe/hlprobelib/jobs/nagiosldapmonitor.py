from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosLDAPMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [bool],
        [bool],
        [int],
    ]
    name = 'monitor-ldap'
    executable = utils.get_monitor_binary('check_ldap', style='nagios')

    def _run(self, hostname, timeout, port, password, base_dn, bind_dn, attribute, starttls, ssl, version):
        log.debug('%s._run starting _run.' % (self))
        args = []
        self._addArg(args, '-H', hostname)
        self._addArg(args, '-t', timeout)
        if port:
            self._addArg(args, '-p', port)
        if password:
            self._addArg(args, '-P', password)
        self._addArg(args, '-b', base_dn or '')
        if bind_dn:
            self._addArg(args, '-D', bind_dn)
        if attribute:
            self._addArg(args, '-a', attribute)
        if starttls:
            self._addArg(args, '-T')
        if ssl:
            self._addArg(args, '-S')
        if version == 2:
            self._addArg(args, '-2')
        elif version == 3:
            self._addArg(args, '-3')
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosLDAPMonitorJob)
