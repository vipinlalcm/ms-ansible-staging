import urlparse

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosHTTPMonitor2Job(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-http-2'
#    executable = '/usr/lib/nagios/plugins/check_http'
    executable = utils.get_monitor_binary('check_http', style='nagios')

    def _run(self, hostname, timeout, url, match_string):
        log.debug('%s._run starting _run.' % (self))
        try:
            args = self._makeArgs(hostname, timeout, url, match_string)
        except Exception, e:
            self.result['errormsg'] = str(e)
            self.setFailure()
        else:
            self._runPlugin(self.executable, args, timeout)

    def _makeArgs(self, hostname, timeout, url, match_string):
        args = []
        self._addArg(args, '-t', timeout)
        if not url:
            url = 'http://%s/' % hostname
        if not url.startswith('http://') and not url.startswith('https://'):
            url = 'http://%s' % (url)
        split_url = urlparse.urlsplit(url)
        port = split_url.port or 80
        if split_url.scheme == 'https' and not split_url.port:
            port = 443
        self._addArg(args, '-p', port)
        self._addArg(args, '-H', split_url.hostname)
        path = split_url.path or '/'
        if split_url.query:
            path = '%s?%s' % (path, split_url.query)
        self._addArg(args, '-u', path)
        if split_url.username or split_url.password:
            self._addArg(args, '-a', '%s:%s' % (split_url.username, split_url.password))
        if match_string:
            if type(match_string) == unicode:
                match_string = match_string.encode('utf-8')
            self._addArg(args, '-s', match_string)
        if split_url.scheme == 'https':
            self._addArg(args, '-S', None)
        self._addArg(args, '-f', 'follow')
        return args


nagios.register_job(NagiosHTTPMonitor2Job)
