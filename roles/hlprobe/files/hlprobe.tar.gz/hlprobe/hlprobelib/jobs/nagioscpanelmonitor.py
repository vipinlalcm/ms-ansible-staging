from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosCPanelMonitorJob(nagios.BaseNagiosMonitorJob):
    """Cpanel monitor.

    This is basically a clone of the standard http monitor except that it
    uses a monitor binary that ignores http status 401/access denied, which
    cpanel seems to like sending out.

    The monitor arguments are the same as the http monitor.
    """
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [bool]]
    name = 'monitor-cpanel'
    executable = utils.get_monitor_binary('check_http_cpanel')

    def _run(self, hostname, timeout, port, url, host, match_string,
             valid_status_codes, invalid_status_codes,
             use_ssl):
        log.debug('%s._run starting _run.' % (self))
        if not host:
            host = hostname
        args = []
        self._addArg(args, '-I', hostname)
        self._addArg(args, '-H', host)
        if port:
            self._addArg(args, '-p', port)
        if url:
            self._addArg(args, '-u', url)
        if match_string:
            self._addArg(args, '-s', match_string)
        if use_ssl:
            self._addArg(args, '-S', None)
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosCPanelMonitorJob)
