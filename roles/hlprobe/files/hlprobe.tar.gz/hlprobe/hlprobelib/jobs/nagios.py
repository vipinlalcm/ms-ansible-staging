import os
import re

from hlprobelib.jobs import (base, utils, registry)
from hlprobelib import log


def register_job(cls):
    if not cls.executable:
        log.msg('Not registering nagios job %s due to missing executable' % (cls))
    else:
        registry.job_registry.register(cls)


class NagiosPluginError(Exception):
    pass


class BaseNagiosMonitorJob(base.Job):
    """Base job for monitors that use nagios plugins."""
    perf_resptime_regexp = re.compile('([a-zA-Z]+)=([0-9.]+)([a-zA-Z]+);.*')

    def _runPlugin(self, executable, args, timeout):
        if not os.path.isfile(executable):
            raise NagiosPluginError('executable not found')
        try:
            d = utils.get_process_output(executable, args, include_stderr=True, timeout=timeout)
            d.addCallbacks(self._cbMonitor, self._ebMonitor)
        except Exception, e:
            log.msg('%s._runPlugin failed to call utils.get_process_output: %s' % (self, str(e)))
            self._ebMonitor(e)

    def _encodeMonitorOutput(self, output):
        try:
            if type(output) == str:
                output = output.decode('latin-1', 'replace')
            output = output.encode('utf-8', 'replace')
        except Exception, e:
            log.debug('%s._encodeMonitorOutput: error: %s' % (self, str(e)))
            output = ''
        return output

    def _cbMonitor(self, msg):
        log.debug('%s._cbMonitor: success' % self)
        self.result['monitor output'] = self._encodeMonitorOutput(msg)
        try:
            text, perf = self._parsePluginOutput(msg)
            self._parsePerfData(perf)
        except Exception, e:
            log.msg('%s error parsing nagios monitor process result: %s' % (self, str(e)))
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('%s._ebMonitor: %s' % (self, e))
        self.result['monitor output'] = self._encodeMonitorOutput(str(e.value))
        self.result['errormsg'] = ''
        try:
            if isinstance(e.value, utils.GetOutputProcessProtocolErrorWithOutput):
                text, perf = self._parsePluginOutput(str(e.value))
                if len(text) > 0:
                    self.result['errormsg'] = self._encodeMonitorOutput(text[0])
                self._parsePerfData(perf)
            elif isinstance(e.value, utils.GetOutputProcessTimeout):
                self.result['errormsg'] = 'Timeout'
            else:
                self.result['errormsg'] = 'Error'
        except Exception, e:
            log.msg('%s error parsing nagios monitor process result: %s' % (self, str(e)))
        self.setFailure()

    def _makeDefaultArgs(self, hostname):
        args = ['-H', hostname]
        return args

    def _addArg(self, args, option, value):
        args.append(option)
        if value is not None:
            args.append(value)
        return args

    def _parsePluginOutput(self, output):
        perf = []
        if '|' not in output:
            text = output
        else:
            text, perf = output.split('|', 1)
            perf = perf.split('|')
        text = text.split('\n')
        return text, perf

    def _parsePerfData(self, perf):
        """Parser nagios performance data."""
        resp_time = self._parsePerfResponseTime(perf)
        if resp_time is not None:
            self.setMetric('response time', resp_time)
            self.result['response time'] = resp_time

    def _parsePerfResponseTime(self, perf):
        ret = None
        if len(perf) < 1:
            return ret
        match = self.perf_resptime_regexp.match(perf[0])
        if match:
            _type, value, suffix = match.groups()
            try:
                value = float(value)
            except:
                return ret
            if suffix == 'ms':
                ret = value / 1000
            elif suffix == 's':
                ret = value
        return ret
