from twisted.internet import reactor
from twisted.internet.protocol import Protocol, ClientFactory
from twisted.protocols import policies
from twisted.internet import defer

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class TCPMonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [bool]]
    name = 'monitor-tcp-native'

    def _run(self, hostname, timeout, port, send_str='', recv_str='',
             wait_peer_disconnect=False):
        log.debug('%s._run starting _run.' % (self))
        d = defer.Deferred()
        d.addCallbacks(self._cbMonitor, self._ebMonitor)
        f = _TCPMonitorFactory(send_str, recv_str, d, timeout,
                               wait_peer_disconnect)
        reactor.connectTCP(hostname, port, f,
                           timeout=timeout)

    def _cbMonitor(self, msg):
        log.debug('TCPMonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('TCPMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()


registry.job_registry.register(TCPMonitorJob)


class _TCPMonitorFactory(ClientFactory):
    def __init__(self, send_str, recv_str, deferred, timeout,
                 wait_peer_disconnect):
        self._send_str = send_str
        self._recv_str = recv_str
        self._deferred = deferred
        self._timeout = timeout
        self._wait_peer_disconnect = wait_peer_disconnect

    # connector.stopConnecting() can be used to stop the connection attempt.
    def startedConnecting(self, connector):
        pass

    def buildProtocol(self, addr):
        return _TCPMonitorProtocol(self)

    def clientConnectionLost(self, connector, reason):
        pass

    def clientConnectionFailed(self, connector, reason):
        self._deferred.errback(reason)


class _TCPMonitorProtocol(Protocol, policies.TimeoutMixin):
    timeOut = 10

    def __init__(self, factory):
        self._factory = factory
        self._recv_matched = False
        self._complete = False
        self._timed_out = False
        self.setTimeout(self._factory._timeout)
        if len(self._factory._recv_str) == 0:
            self._recv_matched = True

    def connectionMade(self):
        if len(self._factory._send_str) > 0:
            self.transport.write(self._factory._send_str.encode('utf-8'))
        if not self._factory._wait_peer_disconnect and \
                        len(self._factory._recv_str) == 0:
            self.transport.loseConnection()

    def dataReceived(self, data):
        if not self._recv_matched and len(self._factory._recv_str) > 0:
            if self._factory._recv_str in data:
                self._recv_matched = True
        if self._recv_matched and not self._factory._wait_peer_disconnect:
            self.transport.loseConnection()

    def connectionLost(self, reason):
        self._complete = True
        d = self._factory._deferred
        if self._timed_out:
            if not self._recv_matched:
                d.errback(errors.HLProbeError('timeout waiting for response'))
            elif self._factory._wait_peer_disconnect:
                d.errback(errors.HLProbeError('timeout waiting for peer disconnect'))
        elif not self._recv_matched:
            d.errback(errors.HLProbeError('invalid response from peer'))
        else:
            d.callback('')
        self._factory = None

    def timeoutConnection(self):
        if not self._complete:
            self._timed_out = True
            self.transport.loseConnection()


