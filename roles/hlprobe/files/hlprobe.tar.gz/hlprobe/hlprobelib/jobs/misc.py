import time

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class NOOPJob(base.Job):
    """A job that does nothing."""
    name = 'noop'
    pass


registry.job_registry.register(NOOPJob)


class FailJob(base.Job):
    """A job that always fails."""
    name = 'fail'

    def _run(self):
        self.result['errormsg'] = 'error!'
        self.setFailure()


registry.job_registry.register(FailJob)


class SleepJob(base.Job):
    """A job that sleeps for the specified number of seconds."""
    arg_spec = [[int, float]]
    name = 'sleep'

    def _run(self, sleep_time):
        self._callInThread(self._run_thread, True, *self.args)

    def _run_thread(self, sleep_time):
        time.sleep(sleep_time)
        self.setSuccess()


registry.job_registry.register(SleepJob)

