from email.mime.text import MIMEText
from twisted.mail.smtp import sendmail
from twisted.internet.defer import Deferred
from twisted.internet import reactor

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class AlertJob(base.Job):
    arg_spec = [[list]]
    name = 'alert'

    def _run(self, contacts):
        log.debug('%s._run called with %s.' % (self, contacts))
        self._contacts = contacts
        self._informNextContact()

    def _informNextContact(self):
        contact = None
        while len(self._contacts) > 0:
            contact = self._contacts.pop()
            if contact['type'] == 'email':
                self._sendEmail(contact)
            elif contact['type'] == 'pager':
                pass
            else:
                pass
        if len(self._contacts) == 0 and contact is None:
            self.setSuccess()

    def _sendEmail(self, contact):
        log.debug('AlertJob._sendEmail sending mail, %s.' % (contact))
        msg = MIMEText(contact['text'].encode('utf-8'),
                       _charset='utf-8')
        msg['Subject'] = contact['subject']
        msg['From'] = contact['from']
        msg['To'] = contact['to']
        d = sendmail('localhost', contact['from'], [contact['to']],
                     msg.as_string())
        d.addCallbacks(self._cbDelivery, self._ebDelivery)

    def _cbDelivery(self, result):
        self._informNextContact()

    def _ebDelivery(self, error):
        self._informNextContact()


registry.job_registry.register(AlertJob)
