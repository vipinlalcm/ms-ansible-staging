from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosHTTPMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [bool]]
    name = 'monitor-http'
#    executable = '/usr/lib/nagios/plugins/check_http'
    executable = utils.get_monitor_binary('check_http', style='nagios')

    def _run(self, hostname, timeout, port, url, host, match_string,
             valid_status_codes, invalid_status_codes,
             use_ssl):
        log.debug('%s._run starting _run.' % (self))
        if not host:
            host = hostname
        args = []
        self._addArg(args, '-I', hostname)
        self._addArg(args, '-H', host)
        self._addArg(args, '-t', timeout)
        if port:
            self._addArg(args, '-p', port)
        if url:
            self._addArg(args, '-u', url)
        if match_string:
            self._addArg(args, '-s', match_string)
        if use_ssl:
            self._addArg(args, '-S', None)
        if valid_status_codes:
            self._addArg(args, '-e', valid_status_codes)
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosHTTPMonitorJob)
