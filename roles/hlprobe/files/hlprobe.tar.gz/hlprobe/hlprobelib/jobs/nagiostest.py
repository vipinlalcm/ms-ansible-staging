from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log


class NagiosTestMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int]]
    name = 'monitor-nagiostest'
    executable = '/tmp/check_ping'

    def _run(self, hostname, timeout):
        log.debug('%s._run starting _run.' % (self))
        args = ['-H', hostname, '-w', '1,5%', '-c', '1,5%']
        self._runPlugin(self.executable, args, timeout)


registry.job_registry.register(NagiosTestMonitorJob)
