from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log

import sys
import traceback

try:
    from ImcSdk import *
    can_monitor = True
except ImportError:
    can_monitor = False

class ImcConnect(object):
    def __init__(self, host, port,  user, password, ssl = True):
        self.imc_host = host
        self.imc_user = user
        self.imc_password = password
        self.imc_port = port
        self.imc_ssl = ssl
        self.imc_connection = self._imc_connect()

    def _imc_connect(self):
        handle = ImcHandle()
        if self.imc_ssl:
            nossl = True
        else:
            nossl = False

        if handle.login(self.imc_host, username = self.imc_user, password = self.imc_password, port = self.imc_port, nossl = nossl):
            return handle
        else:
            return False

    def _imc_disconnect(self):
        if self.imc_connection:
            self.imc_connection.logout()

    def _get_imc_faults(self):
        data = []
        faults = self.imc_connection.get_imc_managedobject(in_mo = None, class_id = NamingId.FAULT_INST, params = None, in_hierarchical = False)
        for fault in faults:
            data.append({
                'ack': fault.get_attr(FaultInst.ACK).lower(),
                'affected_dn': fault.get_attr(FaultInst.AFFECTED_DN).lower(),
                'cause': fault.get_attr(FaultInst.CAUSE).lower(),
                'change_set': fault.get_attr(FaultInst.CHANGE_SET),
                'code': fault.get_attr(FaultInst.CODE).lower(),
                'created': fault.get_attr(FaultInst.CREATED).lower(),
                'description': fault.get_attr(FaultInst.DESCR).lower(),
                'dn': fault.get_attr(FaultInst.DN).lower(),
                'highest_severity': fault.get_attr(FaultInst.HIGHEST_SEVERITY).lower(),
                'id': fault.get_attr(FaultInst.ID).lower(),
                'last_transition': fault.get_attr(FaultInst.LAST_TRANSITION).lower(),
                'lc': fault.get_attr(FaultInst.LC).lower(),
                'occur': fault.get_attr(FaultInst.OCCUR).lower(),
                'orig_severity': fault.get_attr(FaultInst.ORIG_SEVERITY).lower(),
                'prev_severity': fault.get_attr(FaultInst.PREV_SEVERITY).lower(),
                'rn': fault.get_attr(FaultInst.RN).lower(),
                'rule': fault.get_attr(FaultInst.RULE).lower(),
                'severity': fault.get_attr(FaultInst.SEVERITY).lower(),
                'status': fault.get_attr(FaultInst.STATUS),
                'tags': fault.get_attr(FaultInst.TAGS).lower(),
                'type': fault.get_attr(FaultInst.TYPE).lower()
            })

        return data

class CiscoIMCJob(base.Job):
    """ A job for monitoring Cisco IMC Hardware Status"""
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [bool],
        [str, unicode],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-cisco-imc-hw'

    def _run(self, hostname, timeout, port, usessl, user, password, ignore_list):
        log.debug('%s._run starting _run.' % (self))
        try:
            if can_monitor:
                self._callInThread(self._run_thread, True, *self.args)
            else:
                self.result['errormsg'] = 'Cannot find ImcSdk, install it on probe.'
                self.setFailure()
        except Exception, e:
            self.result['errormsg'] = "robin3: %s" % (str(e))
            self.setFailure()

    def _run_thread(self, hostname, timeout, port, usessl, user, password, ignore_list):
        if not ignore_list:
            ignore_list = []
        else:
            ignore_list = [i.strip() for i in ignore_list.split(',')]
        try:
            imc = ImcConnect(hostname, port, user, password, ssl = usessl)
            if imc.imc_connection:
                faults = imc._get_imc_faults()
                valid_faults = ''
                for fault in faults:
                    fault_desc = fault['description']
                    fault_ref = fault['affected_dn']
                    if not fault_ref in ignore_list:
                        msg = '[%s] %s.' % (fault_ref, fault_desc)
                        valid_faults += '%s\n' % (msg)

                imc._imc_disconnect()

                if valid_faults:
                    self.result['errormsg'] = str(valid_faults)
                    self.setFailure()
                else:
                    self.setSuccess()
            else:
                self.result['errormsg'] = "Could not connect to %s" % (hostname)
                self.setFailure()

            imc = None

        except Exception, e:
            tback = ''.join(traceback.format_exception(sys.exc_type, sys.exc_value, sys.exc_traceback))
            log.debug('debug_robin: %s' % (tback))
            #self.result['errormsg'] = '%s' % (str(e))
            self.result['errormsg'] = 'debug_robin: %s' % (str(tback))
            self.setFailure()

registry.job_registry.register(CiscoIMCJob)

