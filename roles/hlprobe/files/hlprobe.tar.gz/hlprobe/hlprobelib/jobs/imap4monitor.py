import socket
from StringIO import StringIO
import re

from twisted.internet import reactor, protocol, defer, ssl
from twisted.protocols import policies
from twisted.mail import imap4

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class IMAP4MonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [bool],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-imap4'

    def _run(self, hostname, timeout, port, use_ssl=False,
             username='', password=''):
        log.debug('%s._run starting _run.' % (self))
        if len(username) == 0:
            username = None
            password = None
        d = run_imap4monitor(hostname, port, username, password, use_ssl,
                             timeout)
        d.addCallbacks(self._cbMonitor, self._ebMonitor)

    def _cbMonitor(self, msg):
        log.debug('IMAP4MonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('IMAP4MonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = self._parseGenericErrors(e)
        self.setFailure()


registry.job_registry.register(IMAP4MonitorJob)


def run_imap4monitor(hostname, port, username, password, use_ssl,
                     timeout):
    d = defer.Deferred()
    factory = _IMAP4MonitorFactory(d, timeout,
                                   username, password)
    if use_ssl:
        context = ssl.ClientContextFactory()
        reactor.connectSSL(hostname, port, factory,
                           context, timeout=timeout)
    else:
        reactor.connectTCP(hostname, port, factory,
                           timeout=timeout)
    return d


class _IMAP4MonitorFactory(protocol.ClientFactory):
    def __init__(self, deferred, timeout,
                 username, password):
        self.deferred = deferred
        self.timeout = timeout
        self.username = username
        if self.username:
            self.username = self.username.encode('utf-8')
        self.password = password
        if self.password:
            self.password = self.password.encode('utf-8')

    # connector.stopConnecting() can be used to stop the connection attempt.
    def startedConnecting(self, connector):
        pass

    def buildProtocol(self, addr):
        context = None
        #        if self.use_tls:
        #            context = ssl.ClientContextFactory()
        #            context.method = ssl.SSL.TLSv1_METHOD
        proto = _IMAP4MonitorProtocol(self,
                                      self.username, self.password, context)
        return proto

    def clientConnectionFailed(self, connector, reason):
        self.deferred.errback(reason)


class _IMAP4MonitorProtocol(imap4.IMAP4Client):
    timeout = 10

    def __init__(self, factory, username, password, context_factory):
        """Protocol for monitoring a pop3 server.

            username:
                The username to used to login or '' for no login.
            password:
                The password used to login.
        """
        imap4.IMAP4Client.__init__(self, context_factory)
        log.debug('Starting imap4 monitor protocol: %s' % (self))
        self._factory = factory
        self._username = username
        self._password = password
        self._error = None
        self._check_ok = False
        # pop3.AdvancedPOP3Client will keep reseting the timeout from
        # policies.TimeoutMixin as long
        # as it keeps getting valid responses from the server.
        # This could keep our session going for longer than
        # we really want, so we keep a seperate hard timeout
        # that will kill the session regardless of smtp activity.
        self._hard_timeout = reactor.callLater(
            self._factory.timeout + 1, self._hardTimeout)
        self.setTimeout(self._factory.timeout)
        self._registerAuthenticators(username)
        log.debug('IMAP4 init complete: %s' % (self))

    def _registerAuthenticators(self, username):
        self.registerAuthenticator(imap4.CramMD5ClientAuthenticator(username))
        self.registerAuthenticator(imap4.LOGINAuthenticator(username))
        # Plain auth is broken in twisted, see ticket:
        # http://twistedmatrix.com/trac/ticket/3939
        #self.registerAuthenticator(imap4.PLAINAuthenticator(username))

    def sendLine(self, line):
        log.debug('IMAP4 send %s: %s' % (self, line))
        imap4.IMAP4Client.sendLine(self, line)

    def lineReceived(self, line):
        log.debug('IMAP4 recv %s: %s' % (self, line))
        imap4.IMAP4Client.lineReceived(self, line)

    def connectionLost(self, reason):
        log.debug('IMAP4 connection lost %s: %s' % (self, reason))
        imap4.IMAP4Client.connectionLost(self, reason)
        if not self._check_ok:
            self.setError('Invalid response from server')
        if self._hard_timeout:
            self._hard_timeout.cancel()
        if self._error:
            self._factory.deferred.errback(self._error)
        else:
            self._factory.deferred.callback('')

    def setError(self, error):
        log.debug('IMAP4 set error %s: %s' % (self, error))
        if self._error is None:
            if type(error) is str:
                self._error = errors.HLProbeError(error)
            else:
                self._error = error

    def _hardTimeout(self, *args, **kwargs):
        self.setError('Timeout, session took to long')
        self._hard_timeout = None
        self.transport.loseConnection()

    def timeoutConnection(self):
        imap4.IMAP4Client.timeoutConnection(self)
        self.setError('Timeout, session took to long')

    def serverGreeting(self, caps):
        log.debug('IMAP4 servergreeting %s' % (self))
        # If we have no username, just quit.
        if self._username:
            d = self.authenticate(self._password)
            d.addCallbacks(self._cbLogin, self._ebLogin)
        else:
            self._check_ok = True
            self.logout()

    def _cbLogin(self, *args, **kwargs):
        log.debug('IMAP4 _cblogin %s' % (self))
        self._check_ok = True
        self.logout()

    def _ebLogin(self, failure):
        log.debug('IMAP4 _eblogin %s: %s' % (self, str(failure)))
        if failure.check(imap4.NoSupportedAuthentication):
            d = self.login(self._username, self._password)
            d.addCallbacks(self._cbLogin, self._ebGeneric)
        else:
            self.setError(str(failure.value))
            self.logout()

    def _ebGeneric(self, e):
        self.setError(str(e.value))
        self.logout()

