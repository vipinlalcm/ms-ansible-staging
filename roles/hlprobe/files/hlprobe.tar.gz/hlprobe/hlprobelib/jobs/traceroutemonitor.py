import time
import os.path
from twisted.internet import reactor
import twisted.internet.utils
from twisted.internet import defer
import re

from hlprobelib.jobs import (base, utils)
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import geoiputils

MTR_PATHS = ['/usr/bin/mtr', '/opt/local/sbin/mtr']
_mtr_path = None
for mtr_path in MTR_PATHS:
    if os.path.exists(mtr_path):
        _mtr_path = mtr_path
        break


class TracerouteMonitorJob(base.Job):
    arg_spec = [[str, unicode], [int]]
    name = 'monitor-traceroute'
    _mtr_cmdline = '%s --report --report-wide --report-cycles=1 %%s' % (_mtr_path)
    _mtr_regexp = re.compile(
        '^ +[0-9]+\.(?:\|--|) ([^ ]+)[ ]+([0-9.]+)[%]*[ ]+([^ ]+)[ ]+([^ ]+)[ ]+([^ ]+)[ ]+([^ ]+)[ ]+([^ ]+)[ ]+([^ ]+)')

    def _run(self, hostname, timeout):
        log.debug('%s._run starting _run.' % (self))
        hostname = hostname.encode('utf-8')
        self._hostname = hostname
        cmdline = self._mtr_cmdline % (hostname)
        split = cmdline.split(' ')
        try:
            d = utils.get_process_output(split[0], split[1:], include_stderr=True, timeout=timeout,
                                         ignore_exitcodes=True)
            d.addCallbacks(self._success, self._failure)
        except Exception, e:
            log.msg('%s._run failed to call utils.get_process_output: %s' % (self, e))
            self._failure(e)

    @defer.inlineCallbacks
    def _parseMtrOutput(self, output):
        ret = []
        for line in output.split('\n'):
            match = self._mtr_regexp.match(line)
            if match:
                host, loss, snt, last, avg, best, worst, stdev = match.groups()
                pathdict = {'host': host, 'host-ip': '', 'host-country': '', 'loss': loss, 'average': avg, 'best': best,
                            'worst': worst}
                ret.append(pathdict)
        yield self._parseGeoIPHosts(ret)
        defer.returnValue(ret)

    @defer.inlineCallbacks
    def _parseGeoIPHosts(self, routelist):
        dlist = []
        for node in routelist:
            if node['host']:
                d = reactor.resolve(node['host'])
                d.addCallback(self._cbResolve, node)
                dlist.append(d)
        result = yield defer.DeferredList(dlist, consumeErrors=1)

    def _cbResolve(self, ipaddr, node):
        if ipaddr:
            node['host-ip'] = ipaddr
            node['host-country'] = geoiputils.country_name_by_ip(ipaddr) or ''
        return (ipaddr, node)

    @defer.inlineCallbacks
    def _success(self, result):
        self.result['route'] = yield self._parseMtrOutput(result)
        self.setSuccess()

    def _failure(self, error):
        self.result['errormsg'] = str(error)
        self.setFailure()


registry.job_registry.register(TracerouteMonitorJob)

