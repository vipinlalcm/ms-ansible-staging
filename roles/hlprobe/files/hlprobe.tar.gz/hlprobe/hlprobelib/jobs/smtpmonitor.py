import socket
from StringIO import StringIO

from twisted.internet import reactor, protocol, defer, ssl
from twisted.protocols import policies
from twisted.mail import smtp

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log

_HOSTNAME = socket.gethostname()


class SMTPMonitorJob(base.Job):
    """Monitor an (E)SMTP server.

    Connect to an smtp server and check for valid responses.
    If mail_from is set a test mail is also sent.
    """
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [bool],
        [bool],
        [bool],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-smtp'

    def _run(self, hostname, timeout, port, mail_from='', mail_to='',
             use_ssl=False, use_tls=False, use_auth=False,
             username='', secret=''):
        log.debug('%s._run starting _run.' % (self))
        # No mail will be sent if mail_from is not set.
        if len(mail_from) == 0:
            mail_from = None
        d = run_smtpmonitor(hostname, port, mail_from, mail_to,
                            use_ssl, use_tls, use_auth, username, secret, timeout,
                            message=None)
        d.addCallbacks(self._cbMonitor, self._ebMonitor)

    def _cbMonitor(self, msg):
        log.debug('SMTPMonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('SMTPMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = self._parseGenericErrors(e)
        self.setFailure()


registry.job_registry.register(SMTPMonitorJob)


def run_smtpmonitor(hostname, port, mail_from, mail_to,
                    use_ssl, use_tls, use_auth,
                    username, secret, timeout, message):
    d = defer.Deferred()
    factory = _SMTPMonitorFactory(d, timeout, use_tls, use_auth,
                                  username, secret, mail_from, mail_to, message, hostname)
    if use_ssl:
        context = ssl.ClientContextFactory()
        reactor.connectSSL(hostname, port, factory,
                           context, timeout=timeout)
    else:
        reactor.connectTCP(hostname, port, factory,
                           timeout=timeout)
    return d


class _SMTPMonitorFactory(protocol.ClientFactory):
    def __init__(self, deferred, timeout, use_tls, use_auth,
                 username, secret, mail_from, mail_to, message, hostname):
        self.deferred = deferred
        self.timeout = timeout
        self.use_tls = use_tls
        self.use_auth = use_auth
        self.username = username
        self.secret = secret
        if type(self.secret) == unicode:
            self.secret = self.secret.encode('utf-8')
        self.mail_from = mail_from
        self.mail_to = mail_to
        self.message = message
        self.hostname = hostname
        if type(self.mail_from) == unicode:
            self.mail_from = self.mail_from.encode('utf-8')
        if type(self.mail_to) == unicode:
            self.mail_to = self.mail_to.encode('utf-8')

    # connector.stopConnecting() can be used to stop the connection attempt.
    def startedConnecting(self, connector):
        pass

    def buildProtocol(self, addr):
        context = None
        if self.use_tls:
            context = ssl.ClientContextFactory()
            context.method = ssl.SSL.TLSv1_METHOD
        proto = _SMTPMonitorProtocol(self,
                                     self.mail_from,
                                     self.mail_to,
                                     self.use_auth,
                                     self.username,
                                     self.secret,
                                     self.message,
                                     context,
                                     identity=_HOSTNAME)
        if self.use_tls:
            proto.requireTransportSecurity = True
        return proto

    def clientConnectionFailed(self, connector, reason):
        self.deferred.errback(reason)


class _SMTPMonitorProtocol(smtp.ESMTPClient):
    # policies.timeoutmixing seems to want timeOut, SMTP class wants
    # timeout..?
    timeout = 60
    timeOut = 60
    _default_message = """From: %s
To: %s
Subject: hlprobe test message
"""

    def __init__(self, factory, mail_from, mail_to,
                 use_auth, username, secret, message,
                 contextFactory, *args, **kwargs):
        smtp.ESMTPClient.__init__(self, secret, contextFactory,
                                  *args, **kwargs)
        self._factory = factory
        self._error = None
        self._mail_sent = False
        self._mail_from = mail_from
        self._mail_to = mail_to
        self._message = message
        if use_auth:
            self.requireAuthentication = True
            self._registerAuthenticators(username)
            # smtp.ESMTPClient will keep reseting the timeout from
        # policies.TimeoutMixin as long
        # as it keeps getting valid responses from the server.
        # This could keep our session going for longer than
        # we really want, so we keep a seperate hard timeout
        # that will kill the session regardless of smtp activity.
        self._hard_timeout = reactor.callLater(
            self._factory.timeout + 1, self._hardTimeout)
        self.timeout = self.timeOut = self._factory.timeout
        self.setTimeout(self._factory.timeout)

    def _registerAuthenticators(self, username):
        self.registerAuthenticator(smtp.CramMD5ClientAuthenticator(username))
        self.registerAuthenticator(smtp.LOGINAuthenticator(username))
        self.registerAuthenticator(smtp.PLAINAuthenticator(username))

    def sendLine(self, line):
        log.debug('send(%s): %s' % (self._factory.hostname, line))
        smtp.ESMTPClient.sendLine(self, line)

    def lineReceived(self, line):
        log.debug('recv(%s): %s' % (self._factory.hostname, line))
        smtp.ESMTPClient.lineReceived(self, line)

    def getMailFrom(self):
        if not self._mail_sent:
            self._mail_sent = True
            return self._mail_from
        else:
            return None

    def getMailTo(self):
        return [self._mail_to]

    def sentMail(self, code, resp, numOk, addresses, log):
        if resp == 'No recipients accepted' or code == -1:
            self.setError('%d %s' % (code, resp))

    def getMailData(self):
        if self._message:
            msg = self._message
        else:
            msg = self._default_message % (
                self._mail_from,
                self._mail_to)

        m = StringIO(msg)
        return m

    def connectionLost(self, reason):
        smtp.ESMTPClient.connectionLost(self, reason)
        if self._hard_timeout is True:
            self.setError('Timeout, session took to long')
        else:
            self._hard_timeout.cancel()
            # self._okresponse should be set to self.smtpState_disconnect
        # if it's not, and self._error is not set,
        # we have been disconnected without recieving anything from the
        # server.
        # Most other errors should be handled by self.sendError.
        if self._okresponse != self.smtpState_disconnect and not self._error:
            self.setError('Invalid response from server')
        if self._error:
            self._factory.deferred.errback(self._error)
        else:
            self._factory.deferred.callback('')

    def sendError(self, exc):
        """Error handler in smtp.ESMTPClient.

        Called with different exceptions for a number of different
        errors in the parent class. Gracefully disconnects from the
        smtp server if possible.
        """
        smtp.ESMTPClient.sendError(self, exc)
        self.setError(exc.resp)

    def setError(self, error):
        if self._error is None:
            if type(error) is str:
                self._error = errors.HLProbeError(error)
            else:
                self._error = error

    def _hardTimeout(self, *args, **kwargs):
        self._hard_timeout = True
        self.transport.loseConnection()

