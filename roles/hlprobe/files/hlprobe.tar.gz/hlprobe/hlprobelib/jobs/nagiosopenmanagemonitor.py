from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosOpenManageMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [str, unicode],
        [str, unicode],
        [int],
        [str, unicode],
        [bool],
    ]
    name = 'monitor-open-manage'
    executable = utils.get_monitor_binary('check_openmanage')

    def _run(self, hostname, timeout, community, protocol, port, blacklist, all):
        log.debug('%s._run starting _run.' % (self))
        if not host:
            host = hostname
        args = []
        self._addArg(args, '-t', timeout)
        self._addArg(args, '-H', hostname)
        self._addArg(args, '-C', community)
        self._addArg(args, '-P', protocol)
        self._addArg(args, '--port', port)
        if blacklist:
            self._addArg(args, '-b', blacklist)
        if all:
            self._addArg(args, '-a', None)
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosOpenManageMonitorJob)
