from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosTCPMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [bool]]
    name = 'monitor-tcp'
#    executable = '/usr/lib/nagios/plugins/check_tcp'
    executable = utils.get_monitor_binary('check_tcp', style='nagios')

    def _run(self, hostname, timeout, port, send_str='', recv_str='',
             wait_peer_disconnect=False):
        log.debug('%s._run starting _run.' % (self))
        args = []
        self._addArg(args, '-H', hostname)
        self._addArg(args, '-p', port or 80)
        self._addArg(args, '-t', timeout or 10)
        if send_str:
            self._addArg(args, '-s', send_str)
        if recv_str:
            self._addArg(args, '-e', recv_str)
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosTCPMonitorJob)
