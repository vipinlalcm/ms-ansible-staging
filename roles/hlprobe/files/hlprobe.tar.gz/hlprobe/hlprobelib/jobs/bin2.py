import os
import json

from hlprobelib.jobs import (base, utils)
from hlprobelib import log


class Bin2PluginError(Exception):
    pass


class BaseBin2MonitorJob(base.Job):
    """Base job for monitors that use bin2 compatible plugins."""

    def _makeDefaultArgs(self):
        args = ['-bin2=true']
        return args

    def _addArg(self, args, option, value):
        args.append(option)
        if value is not None:
            args.append(value)
        return args

    def _runPlugin(self, executable, args, timeout, bin2_args):
        if not os.path.isfile(executable):
            raise Bin2PluginError('executable not found')
        bin2_in = json.dumps(bin2_args)
        try:
            d = utils.get_process_output(executable, args, include_stderr=True, timeout=timeout+1, stdin_data=bin2_in)
            d.addCallbacks(self._cbMonitor, self._ebMonitor)
        except Exception, e:
            log.msg('%s._runPlugin failed to call utils.get_process_output: %s' % (self, str(e)))
            self._ebMonitor(e)

    def _cbMonitor(self, msg):
        log.debug('%s._cbMonitor: success' % self)
        bin2_resp = self._parseBin2Response(msg)
        if bin2_resp:
            self._parseBin2Metrics(bin2_resp)
            if bin2_resp.get('ErrorMsg'):
                self.result['errormsg'] = bin2_resp.get('ErrorMsg')
            if bin2_resp['Status'] == 'OK':
                self.setSuccess()
            else:
                self.setFailure()
        else:
            self.setErrorMsg('unable to parse bin2 data')
            self.setFailure()

    def _parseBin2Response(self, data):
        ret = None
        try:
            ret = json.loads(data)
        except Exception, e:
            log.msg('%s error parsing bin2 monitor process result: %s' % (self, str(e)))
        else:
            if type(ret.get('ErrorMsg')) == unicode:
                ret['ErrorMsg'] = ret['ErrorMsg'].encode('utf-8')
        return ret

    def _parseBin2Metrics(self, data):
        metrics = data.get('Metrics')
        if metrics:
            for name, value in metrics.iteritems():
                if type(name) == unicode:
                    name = name.encode('utf-8')
                self.setMetric(name, value)
            if 'response time' in metrics:
                self.result['response time'] = data['Metrics']['response time']

    def _ebMonitor(self, e):
        log.debug('%s._ebMonitor: %s' % (self, e))
        self.result['errormsg'] = ''
        try:
            if isinstance(e.value, utils.GetOutputProcessProtocolErrorWithOutput):
                bin2_resp = self._parseBin2Response(str(e.value))
                if bin2_resp:
                    self._parseBin2Metrics(bin2_resp)
                    if bin2_resp.get('ErrorMsg'):
                        self.result['errormsg'] = bin2_resp.get('ErrorMsg')
                else:
                    pass
            elif isinstance(e.value, utils.GetOutputProcessTimeout):
                self.result['errormsg'] = 'Timeout'
            else:
                self.result['errormsg'] = 'Error'
        except Exception, e:
            log.msg('%s error parsing bin2 monitor process result: %s' % (self, str(e)))
        self.setFailure()

