from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils

DNS_SERVER_LIST = [('10.0.10.10', 53), ('10.0.11.11', 53)]


class NagiosDNSMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [str, unicode],
        [bool],
        [list, str, unicode],
        [bool],
    ]
    name = 'monitor-dns'
    executable = utils.get_monitor_binary('check_dns', style='nagios')

    def _run(self, hostname, timeout, query_string='',
             require_authority=False,
             required_response=None,
             local_query=True):
        log.debug('%s._run starting _run.' % (self))
        if required_response is None:
            required_response = []
        if not query_string:
            query_string = 'www.monitorscout.com'
        if type(required_response) in [str, unicode]:
            required_response = required_response.split()
        args = []
        self._addArg(args, '-H', query_string)
        if not local_query:
            self._addArg(args, '-s', hostname)
        if require_authority:
            self._addArg(args, '-A', None)
        for resp in required_response:
            self._addArg(args, '-a', resp)
        self._runPlugin(self.executable, args, timeout)

nagios.register_job(NagiosDNSMonitorJob)
