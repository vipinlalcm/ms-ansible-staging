from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils

class NagiosNTPTimeMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
    ]
    name = 'monitor-ntp-time'
    executable = utils.get_monitor_binary('check_ntp_time', style='nagios')

    def _run(self, hostname, timeout):
        log.debug('%s._run starting _run.' % (self))
        args = ['-H', hostname]
        self._runPlugin(self.executable, args, timeout)

nagios.register_job(NagiosNTPTimeMonitorJob)
