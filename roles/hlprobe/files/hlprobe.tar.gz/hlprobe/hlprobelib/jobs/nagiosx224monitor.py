from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosX224MonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [int]]
    name = 'monitor-x224'
    executable = utils.get_monitor_binary('check_x224')

    def _run(self, hostname, timeout, port):
        log.debug('%s._run starting _run.' % (self))
        args = self._makeDefaultArgs(hostname)
        if port:
            self._addArg(args, '-p', port)
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosX224MonitorJob)
