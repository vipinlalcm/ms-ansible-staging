from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosPGSQLMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-pgsql'
#    executable = '/usr/lib/nagios/plugins/check_pgsql'
    executable = utils.get_monitor_binary('check_pgsql', style='nagios')

    def _run(self, hostname, timeout, port, username, password, dbname):
        log.debug('%s._run starting _run.' % (self))
        args = self._makeDefaultArgs(hostname)
        if dbname:
            self._addArg(args, '-d', dbname)
        if port:
            self._addArg(args, '-P', port)
        if password:
            self._addArg(args, '-p', password)
        if username:
            self._addArg(args, '-l', username)
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosPGSQLMonitorJob)
