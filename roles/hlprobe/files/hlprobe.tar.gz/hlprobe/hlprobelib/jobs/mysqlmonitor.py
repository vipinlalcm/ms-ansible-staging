import socket
from StringIO import StringIO
import re

from twisted.internet import reactor, protocol, defer, ssl
from twisted.enterprise import adbapi

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log

#This seems to leak memory for some unknown reason, use the nagios version for now.

class MySQLMonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-mysql-native'

    def _run(self, hostname, timeout, port,
             username, password, dbname=''):
        log.debug('%s._run starting _run.' % (self))
        d = run_mysqlmonitor(hostname, port, timeout, username, password,
                             dbname)
        d.addCallbacks(self._cbMonitor, self._ebMonitor)

    def _cbMonitor(self, msg):
        log.debug('MySQLMonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('MySQLMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()


registry.job_registry.register(MySQLMonitorJob)


def run_mysqlmonitor(hostname, port, timeout, username, password, dbname):
    d = defer.Deferred()
    m = _MySQLMonitor(d, hostname, port, timeout, username, password, dbname)
    return d


class _MySQLMonitor(object):
    def __init__(self, deferred, hostname, port, timeout,
                 username, password, dbname):
        self.deferred = deferred
        self.hostname = hostname.encode('utf-8')
        self.port = port
        self.timeout = timeout
        self.username = username.encode('utf-8')
        self.password = password.encode('utf-8')
        self.dbname = dbname.encode('utf-8')
        self._hard_timeout = reactor.callLater(
            self.timeout + 1, self._hardTimeout)
        self._error = None
        self.dbcon = adbapi.ConnectionPool('MySQLdb',
                                           host=self.hostname,
                                           port=self.port,
                                           user=self.username,
                                           passwd=self.password,
                                           db=self.dbname)
        self.runQuery()

    def runQuery(self):
        d = self.dbcon.runQuery('select 2')
        d.addCallbacks(self._cbRunQuery, self._ebRunQuery)

    def _cbRunQuery(self, result):
        self.done()

    def _ebRunQuery(self, error):
        self.setError(str(error.value))
        self.done()

    def _hardTimeout(self, *args, **kwargs):
        self.setError('Timeout, session took to long')
        self._hard_timeout = None
        self.done()

    def done(self):
        try:
            self.dbcon.close()
        except:
            pass
        if self._hard_timeout:
            self._hard_timeout.cancel()
        if self._error:
            self.deferred.errback(self._error)
        else:
            self.deferred.callback('')

    def setError(self, error):
        if self._error is None:
            if type(error) is str:
                self._error = errors.HLProbeError(error)
            else:
                self._error = error

