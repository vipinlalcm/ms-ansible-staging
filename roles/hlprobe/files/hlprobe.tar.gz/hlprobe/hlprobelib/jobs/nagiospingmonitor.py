from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class NagiosPingMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [[str, unicode], [int]]
    name = 'monitor-ping'
#    executable = '/usr/lib/nagios/plugins/check_ping'
    executable = utils.get_monitor_binary('check_ping', style='nagios')

    def _run(self, hostname, timeout):
        log.debug('%s._run starting _run.' % (self))
        args = []
        self._addArg(args, '-H', hostname)
        self._addArg(args, '-w', 5000)
        args.append(90)
        self._addArg(args, '-c', 5000)
        args.append(90)
        self._addArg(args, '-p', 2)
        self._addArg(args, '-4', None)
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(NagiosPingMonitorJob)
