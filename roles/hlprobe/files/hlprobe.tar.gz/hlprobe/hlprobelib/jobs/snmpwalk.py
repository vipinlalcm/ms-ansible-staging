import xmlrpclib
import cPickle as pickle

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import snmp
from hlprobelib import errors
from hlprobelib import log


class SNMPWalkJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode, int],
        [dict],
        [list]]
    name = 'snmp-walk'

    def _run(self, hostname, timeout, port, version, auth_info, oids):
        log.debug('%s._run starting _run.' % (self))
        self.walker = None
        try:
            self.walker = snmp.SNMPWalker(hostname, port, version, auth_info,
                                          timeout)
            d = self.walker.walk(oids)
            d.addCallbacks(self._cbWalk, self._ebWalk)
        except Exception, e:
            log.debug('SNMPWalkJob._run error: %s(%s)' % (type(e), e))
            self.result['errormsg'] = str(e)
            self.setFailure()
            if self.walker:
                self.walker.close()

    def _cbWalk(self, result):
        log.debug('SNMPWalkJob._cbWalk: success')
#        print 'RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR', result
        self.result['response'] = result
        # self.setMetric('response time', self.result['runtime'])
        self.setSuccess()
        self.walker.close()

    def _ebWalk(self, e):
        log.debug('SNMPWalkJob._ebWalk: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()
        self.walker.close()


registry.job_registry.register(SNMPWalkJob)

