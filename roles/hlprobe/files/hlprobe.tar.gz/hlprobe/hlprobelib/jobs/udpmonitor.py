from twisted.internet import reactor
from twisted.internet.protocol import DatagramProtocol
from twisted.protocols import policies
from twisted.internet import defer

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class UDPMonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-udp-native'

    def _run(self, hostname, timeout, port, send_str, recv_str):
        log.debug('%s._run starting _run.' % (self))
        d = defer.Deferred()
        d.addCallbacks(self._cbMonitor, self._ebMonitor)
        p = _UDPMonitorProtocol(hostname, port, send_str, recv_str, d, timeout)
        reactor.listenUDP(0, p)

    def _cbMonitor(self, msg):
        log.debug('UDPMonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('UDPMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()


registry.job_registry.register(UDPMonitorJob)


class _UDPMonitorProtocol(DatagramProtocol, policies.TimeoutMixin):
    timeOut = 10

    def __init__(self, hostname, port, send_str, recv_str, deferred, timeout):
        self.hostname = hostname
        self.port = port
        self.send_str = send_str
        self.recv_str = recv_str
        self.deferred = deferred
        self.timeout = timeout
        self.timed_out = False
        self._complete = False
        self.setTimeout(self.timeout)

    @defer.inlineCallbacks
    def startProtocol(self):
        ipaddr = yield reactor.resolve(self.hostname)
        self.transport.connect(ipaddr, self.port)
        self.transport.write(self.send_str.encode('utf-8'))

    def datagramReceived(self, data, host):
        if self.recv_str in data:
            self.complete()

    def complete(self):
        if self._complete:
            return
        self.transport.stopListening()
        self._complete = True
        if self.timed_out:
            self.deferred.errback(errors.HLProbeError('timeout waiting for response'))
        else:
            self.deferred.callback('')

    def timeoutConnection(self):
        if not self._complete:
            self.timed_out = True
            self.complete()
