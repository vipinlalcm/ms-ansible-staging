import urllib
import re

from twisted.internet import protocol, reactor, defer, ssl
from twisted.protocols import policies
from twisted.internet import defer
from twisted.web import http

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class HTTPMonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [str, unicode],
        [bool]]
    name = 'monitor-http-native'

    def _run(self, hostname, timeout, port, url, host, match_string,
             valid_status_codes, invalid_status_codes,
             use_ssl):
        log.debug('%s._run starting _run.' % (self))
        if not host:
            host = hostname
        factory = HTTPMonitorFactory(url, host, match_string,
                                     valid_status_codes, invalid_status_codes, timeout)
        factory.deferred.addCallbacks(self._cbMonitor, self._ebMonitor)
        if use_ssl:
            reactor.connectSSL(hostname, port, factory,
                               ssl.ClientContextFactory(),
                               timeout=timeout)
        else:
            reactor.connectTCP(hostname, port, factory,
                               timeout=timeout)

    def _cbMonitor(self, msg):
        log.debug('HTTPMonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('HTTPMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()


registry.job_registry.register(HTTPMonitorJob)


class HTTPMonitorFactory(protocol.ClientFactory):
    def __init__(self, url, host, match_string, valid_status_codes,
                 invalid_status_codes, timeout):
    #        self.url = urllib.quote_plus(url)
        if len(url) == 0:
            url = '/'
        self.url = url
        self.agent = 'HC/HTTPMonitor'
        self.host = host
        self.match_string = match_string
        self.valid_status_codes = valid_status_codes
        self.invalid_status_codes = invalid_status_codes
        self.timeout = timeout
        self.deferred = defer.Deferred()

    def buildProtocol(self, addr):
        return HTTPMonitorProtocol(self)

    def clientConnectionFailed(self, connector, reason):
        self.deferred.errback(reason)


class HTTPMonitorProtocol(http.HTTPClient, policies.TimeoutMixin):
    timeOut = 10
    max_resp_size = 1024 * 1024 * 10 # 10Mb

    def __init__(self, factory):
        self.factory = factory
        self._complete = False
        self._error = None
        self._recieved_data_size = 0
        if len(factory.match_string) == 0:
            self._string_matched = True
        if len(factory.valid_status_codes) == 0:
            self._valid_status_codes = '.*'
        else:
            self._valid_status_codes = factory.valid_status_codes
        if len(factory.invalid_status_codes) == 0:
            self._invalid_status_codes = '^$'
        else:
            self._invalid_status_codes = factory.invalid_status_codes
        self._got_status = False
        self.setTimeout(self.factory.timeout)

    def connectionMade(self):
        self.sendCommand('GET', self.factory.url.encode('utf-8'))
        if len(self.factory.host) > 0:
            self.sendHeader('Host', self.factory.host.encode('utf-8'))
        self.sendHeader('User-Agent', self.factory.agent)
        self.endHeaders()

    def handleHeader(self, key, value):
        pass

    def handleStatus(self, version, status, message):
        self._got_status = True
        if not re.search(self._valid_status_codes, status):
            self.setError('invalid HTTP status code "%s"' % (status))
            log.debug('HTTPMonitorProtocol.handleStatus no match for valid status codes "%s": %s"' % (status, message))
        else:
            log.debug('HTTPMonitorProtocol.handleStatus matched valid status codes "%s": %s"' % (status, message))
        if re.search(self._invalid_status_codes, status):
            self.setError('invalid HTTP status code "%s"' % (status))
            log.debug('HTTPMonitorProtocol.handleStatus matched invalid status codes "%s": %s"' % (status, message))
        else:
            log.debug(
                'HTTPMonitorProtocol.handleStatus no match for invalid status codes "%s": %s"' % (status, message))

    def handleResponse(self, response):
        if len(self.factory.match_string) > 0:
            if not re.search(self.factory.match_string, response):
                self.setError('match string not found')

    def handleResponsePart(self, data):
        self._recieved_data_size += len(data)
        if self._recieved_data_size > self.max_resp_size:
            self.setError('http server response to large, connection dropped')
            self.transport.loseConnection()
        http.HTTPClient.handleResponsePart(self, data)

    def connectionLost(self, reason):
        http.HTTPClient.connectionLost(self, reason)
        self._complete = True
        if not self._got_status:
            self.setError('no http status received from peer')
        if self._error:
            self.factory.deferred.errback(self._error)
        else:
            self.factory.deferred.callback('')

    def timeoutConnection(self):
        if not self._complete:
            self.setError('connection timed out')
            self.transport.loseConnection()

    def setError(self, error):
        if self._error is None:
            if type(error) is str:
                self._error = errors.HLProbeError(error)
            else:
                self._error = error

