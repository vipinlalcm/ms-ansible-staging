import os

from twisted.internet import reactor
from twisted.internet import defer
from twisted.internet import protocol
from twisted.protocols import policies
from twisted.internet.error import (ProcessDone, ProcessTerminated, ProcessExitedAlready)
import traceback

from hlprobelib.jobs import base
from hlprobelib import log


def get_process_output(executable, args, include_stderr=True, timeout=60, ignore_exitcodes=False, stdin_data=None):
    args = list(args)
    # reactor.spawnProcess only accepts string args.
    args = [str(a) for a in args]
    args.insert(0, executable)
    proto = GetOutputProcessProtocol(include_stderr, timeout, ignore_exitcodes, stdin_data=stdin_data)
    process_transport = reactor.spawnProcess(proto, executable, args, os.environ)
    return proto.deferred


class GetOutputProcessProtocolError(Exception):
    pass


class GetOutputProcessProtocolErrorWithOutput(GetOutputProcessProtocolError):
    pass


class GetOutputProcessTimeout(GetOutputProcessProtocolError):
    pass


class GetOutputProcessProtocol(protocol.ProcessProtocol, policies.TimeoutMixin):
    def __init__(self, include_stderr, timeout, ignore_exitcodes=False, valid_status_codes=None, stdin_data=None):
        # Avoid using a mutable list as argument value.
        if valid_status_codes is None:
            valid_status_codes = [0]
        self.include_stderr = include_stderr
        self.ignore_exitcodes = ignore_exitcodes
        self.valid_status_codes = valid_status_codes
        self.stdin_data = stdin_data
        self.deferred = defer.Deferred()
        self._deferred_called = False
        self._outdata = []
        self._errdata = []
        self.retcode = None
        self.msg = ''
        self._timedout = False
        self._process_ended_called = False
        self.setTimeout(timeout)

    def connectionMade(self):
        if self.stdin_data is not None:
            self.transport.writeToChild(0, self.stdin_data)
            self.transport.closeStdin()

    def outReceived(self, data):
        self._outdata.append(data)

    def errReceived(self, data):
        self._errdata.append(data)

    def processEnded(self, status):
        try:
            self._process_ended_called = True
            self.setTimeout(None)
            outdata = self.getCombinedOutput(self.include_stderr)
            if self._timedout:
                self.retErr(GetOutputProcessTimeout('Timeout'))
            elif hasattr(status, 'value'):
                if self.ignore_exitcodes or status.value.exitCode in self.valid_status_codes:
                    self.retOK(outdata)
                else:
                    err = outdata
                    if isinstance(status.value, ProcessTerminated) and \
                                    status.value.signal is not None:
                        err = 'process terminated by signal %s' % (status.value.signal)
                    if self.hasSTDOUTData():
                        self.retErr(GetOutputProcessProtocolErrorWithOutput(err))
                    else:
                        if len(err) == 0:
                            err = str(status.value)
                        self.retErr(GetOutputProcessProtocolError(err))
            else:
                err = outdata
                if len(err) == 0:
                    err = str(status)
                self.retErr(GetOutputProcessProtocolError(err))
        except Exception, e:
            log.msg('%s.processExited caught unhandled exception: %s' % (self, str(e)))
            tbmsg = traceback.format_exc()
            log.debug(tbmsg)
            self.retErr(GetOutputProcessProtocolError(str(e)))

    def retOK(self, result):
        if not self._deferred_called:
            self.deferred.callback(result)

    def retErr(self, result):
        if not self._deferred_called:
            self.deferred.errback(result)

    def timeoutConnection(self):
        self._timedout = True
        if self._process_ended_called:
            log.msg('%s.timeoutConnection: process exited already called, this is strange.' % (self))
            return
        if self.transport:
            self.transport.loseConnection()
            try:
                self.transport.signalProcess('KILL')
            except ProcessExitedAlready:
                log.msg('%s.timeoutConnection: trying to kill process but it\'s already dead.' % (self))

    def getCombinedOutput(self, include_stderr):
        if include_stderr:
            out = self._outdata + self._errdata
        else:
            out = self._outdata
        s = ' '.join(out)
        return s

    def hasSTDOUTData(self):
        if self._outdata:
            return True
        return False

    def hasSTDERRData(self):
        if self._errdata:
            return True
        return False
