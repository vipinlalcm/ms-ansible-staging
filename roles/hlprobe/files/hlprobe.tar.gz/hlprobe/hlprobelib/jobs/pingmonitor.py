import time
import os.path
from twisted.internet import reactor
import twisted.internet.utils

from hlprobelib.jobs import (base, utils)
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log

FPING_PATHS = ['/usr/bin/fping', '/opt/local/sbin/fping', '/usr/local/sbin/fping']
_fping_path = None
for fping_path in FPING_PATHS:
    if os.path.exists(fping_path):
        _fping_path = fping_path
        break


class PingMonitorJob(base.Job):
    arg_spec = [[str, unicode], [int]]
    name = 'monitor-ping-fping'
    _fping_cmdline = '%s -C 1 -q %%s' % (_fping_path)

    def _run(self, hostname, timeout):
        log.debug('%s._run starting _run.' % (self))
        hostname = hostname.encode('utf-8')
        self._hostname = hostname
        cmdline = self._fping_cmdline % (hostname)
        split = cmdline.split(' ')
        try:
            d = utils.get_process_output(split[0], split[1:], include_stderr=True, timeout=timeout,
                                         ignore_exitcodes=True)
            d.addCallbacks(self._fpingSuccess, self._fpingFailure)
        except Exception, e:
            log.msg('%s._run failed to call utils.get_process_output: %s' % (self, e))
            self._fpingFailure(e)

    def _parseFpingOutput(self, output):
        # fping sometimes returns no output, eg. for invalid (missing) hostnames.
        if len(output) == 0:
            return -1
        response_time = None
        for line in output.split('\n'):
            line = line.strip()
            if not line.startswith(self._hostname):
                continue
            split = line.split(':')
            if len(split) != 2:
                continue
            response_time = split[1].strip()
            break
        if response_time == '-':
            response_time = -1
        else:
            # Return response time in seconds.
            try:
                response_time = float(response_time)
            except Exception, e:
                log.msg('%s._parseFpingOutput exception parsing output "%s": %s.' % (self, output, str(e)))
                response_time = None
            else:
                response_time /= 1000
        return response_time

    def _fpingSuccess(self, result):
        response_time = self._parseFpingOutput(result)
        if response_time is -1:
            self.result['errormsg'] = 'No response from host.'
            self.setFailure()
        elif response_time is None:
            self.result['errormsg'] = 'Unable to parse ping output.'
            self.setComplete('internalerror')
        else:
            self.setSuccess()

    def _fpingFailure(self, error):
        self.result['errormsg'] = str(error)
        self.setFailure()


registry.job_registry.register(PingMonitorJob)

