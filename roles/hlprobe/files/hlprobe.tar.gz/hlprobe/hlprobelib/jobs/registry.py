class JobRegistry(object):
    def __init__(self):
        self.jobtypes = {}

    def __iter__(self):
        for job in self.jobtypes.itervalues():
            yield job

    def register(self, job):
        self.jobtypes[job.name] = job


job_registry = JobRegistry()
