import xmlrpclib
import cPickle as pickle

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import snmp
from hlprobelib import errors
from hlprobelib import log


class SNMPGetJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode, int],
        [dict],
        [list]]
    name = 'snmp-get'

    def _run(self, hostname, timeout, port, version, auth_info, oids):
        log.debug('%s._run starting _run.' % (self))
        self.walker = None
        try:
            self.walker = snmp.SNMPWalker(hostname, port, version, auth_info,
                                          timeout)
            d = self.walker.get(oids)
            d.addCallbacks(self._cbGet, self._ebGet)
        except Exception, e:
            log.debug('SNMPGetJob._run error: %s(%s)' % (type(e), e))
            self.result['errormsg'] = str(e)
            self.setFailure()
            if self.walker:
                self.walker.close()

    def _cbGet(self, result):
        log.debug('SNMPGetJob._cbGet: success')
        # self.setMetric('response time', self.result['runtime'])
        self.result['response'] = result
        self.walker.close()
        self.setSuccess()

    def _ebGet(self, e):
        log.debug('SNMPGetJob._ebGet: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.walker.close()
        self.setFailure()


registry.job_registry.register(SNMPGetJob)

