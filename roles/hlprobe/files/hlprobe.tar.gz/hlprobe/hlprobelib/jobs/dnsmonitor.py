from twisted.names.client import createResolver
from twisted.names import dns
from twisted.names import client
from twisted.names.error import *
from twisted.internet import defer
from twisted.internet import reactor

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log

DNS_SERVER_LIST = [('10.0.10.10', 53), ('10.0.11.11', 53)]


class DNSMonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [str, unicode],
        [bool],
        [list, str, unicode],
        [bool],
    ]
    name = 'monitor-dns-native'

    def _run(self, hostname, timeout, query_string='',
             require_authority=False,
             required_response=None,
             local_query=True):
        log.debug('%s._run starting _run.' % (self))
        if required_response is None:
            required_response = []
        d = defer.Deferred()
        d.addCallbacks(self._cbMonitor, self._ebMonitor)
        if not query_string:
            query_string = 'www.monitorscout.com'
        if type(required_response) in [str, unicode]:
            required_response = required_response.split()
        if local_query:
            dns_server_hostname = None
        else:
            dns_server_hostname = hostname
        r = HostnameResolver(d, query_string, timeout, require_authority,
                             required_response, dns_server_hostname)

    def _cbMonitor(self, msg):
        log.debug('DNSMonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('DNSMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()


registry.job_registry.register(DNSMonitorJob)


class HostnameResolver(object):
    def __init__(self, deferred, query_string, timeout, require_authority,
                 required_response, dns_server_hostname):
        self._deferred = deferred
        self._query_string = query_string
        self._timeout = timeout
        self._require_authority = require_authority
        self._required_response = required_response
        self._hard_timeout = reactor.callLater(timeout + 1, self._hardTimeout)
        self._timed_out = False
        servers = DNS_SERVER_LIST
        if dns_server_hostname:
            servers = dns_server_hostname
        if type(servers) in [str, unicode]:
            servers = [(str(servers), 53)]
        self._resolver = client.Resolver(resolv=None, servers=servers)
        d = self._resolver.lookupAddress(query_string, timeout=[1, 5, 10])
        log.debug('HostnameResolver.__init__ (resolver:%s) %s' % (self._resolver, self._query_string))
        d.addCallbacks(self._cbLookup, self._ebLookup)

    def _cbLookup(self, result):
        if self._timed_out:
            return
        log.debug('HostnameResolver._cbLookup (resolver:%s) %s' % (self._resolver, self._query_string))
        self._cancelHardTimeout()
        self._resolver = None
        answer, authority, additional = result
        ips = set()
        authoritive = True
        for rr in answer:
            if rr.type == dns.A:
                ips.add(rr.payload.dottedQuad())
                if not rr.auth:
                    authoritive = False
        if len(ips) == 0:
            self._deferred.errback(
                errors.HLProbeError('no addresses returned'))
            return
        str_ips = ' '.join([str(ip) for ip in ips])
        if self._required_response:
            req_ips = set(self._required_response)
            if req_ips != ips:
                self._deferred.errback(
                    errors.HLProbeError('answer did not match required response: %s' % (str_ips)))
                return
        if self._require_authority and not authoritive:
            self._deferred.errback(
                errors.HLProbeError('answer was not authoritive: %s' % (str_ips)))
            return
        self._deferred.callback(str_ips)

    def _ebLookup(self, error):
        if self._timed_out:
            return
        log.debug('HostnameResolver._ebLookup (resolver:%s) %s %s' % (self._resolver, self._query_string, error))
        self._cancelHardTimeout()
        self._resolver = None
        if issubclass(error.type, DNSQueryTimeoutError) or \
                issubclass(error.type, defer.TimeoutError):
            self._deferred.errback(
                errors.HLProbeError('timeout'))
        elif issubclass(error.type, DNSQueryRefusedError):
            self._deferred.errback(
                errors.HLProbeError('query refused'))
        elif issubclass(error.type, DomainError):
            self._deferred.errback(
                errors.HLProbeError('lookup failed'))
        else:
            self._deferred.errback(
                errors.HLProbeError('unknown error: %s' % (str(error.value))))

    def _hardTimeout(self):
        log.debug('HostnameResolver._hardTimeout (resolver:%s) %s' % (self._resolver, self._query_string))
        self._timed_out = True
        self._hard_timeout = None
        self._resolver = None
        self._deferred.errback(errors.HLProbeError('timeout'))

    def _cancelHardTimeout(self):
        if self._hard_timeout:
            self._hard_timeout.cancel()
            self._hard_timeout = None
