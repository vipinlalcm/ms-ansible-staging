import socket
from StringIO import StringIO
import re

from twisted.internet import reactor, protocol, defer, ssl
from twisted.enterprise import adbapi

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib import errors
from hlprobelib import log


class MSSQLMonitorJob(base.Job):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [str, unicode],
        [str, unicode],
        [str, unicode]]
    name = 'monitor-mssql'

    def _run(self, hostname, timeout, port,
             username, password, dbname=''):
        log.debug('%s._run starting _run.' % (self))
        ### BROKEN
        self.setSuccess()

    ### BROKEN
    #        d = run_mssqlmonitor(hostname, port, timeout, username, password,
    #                dbname)
    #        d.addCallbacks(self._cbMonitor, self._ebMonitor)

    def _cbMonitor(self, msg):
        log.debug('MSSQLMonitorJob._cbMonitor: success')
        self.setSuccess()

    def _ebMonitor(self, e):
        log.debug('MSSQLMonitorJob._ebMonitor: %s' % (e))
        self.result['errormsg'] = str(e.value)
        self.setFailure()


registry.job_registry.register(MSSQLMonitorJob)


def run_mssqlmonitor(hostname, port, timeout, username, password, dbname):
    d = defer.Deferred()
    m = _MSSQLMonitor(d, hostname, port, timeout, username, password, dbname)
    return d


class _MSSQLMonitor(object):
    def __init__(self, deferred, hostname, port, timeout,
                 username, password, dbname):
        self.deferred = deferred
        self.hostname = hostname.encode('utf-8')
        self.port = port
        self.timeout = timeout
        self.username = username.encode('utf-8')
        self.password = password.encode('utf-8')
        self.dbname = dbname.encode('utf-8')
        self._error = None
        self._hard_timeout = reactor.callLater(
            self.timeout + 1, self._hardTimeout)
        self.dbcon = adbapi.ConnectionPool('pymssql',
                                           host=self.hostname,
                                           user=self.username,
                                           password=self.password,
                                           database=self.dbname,
                                           login_timeout=min(60, timeout),
                                           timeout=min(60, timeout))
        self.runQuery()

    @defer.inlineCallbacks
    def runQuery(self):
        try:
            if self.dbname:
                yield self._runQueryWithDB()
            else:
                yield self._runQueryWithoutDB()
        except Exception, e:
            self.setError(str(e))
        finally:
            self.done()

    @defer.inlineCallbacks
    def _runQueryWithDB(self):
        res = yield self.dbcon.runQuery(
            """SELECT 1 FROM sysobjects WHERE xtype = 'U' AND name = 'monitor_scout_test'""")
        if not res:
            res = yield self.dbcon.runOperation("""CREATE TABLE monitor_scout_test(id INT, name VARCHAR(100))""")
            res = yield self.dbcon.runOperation("""INSERT INTO monitor_scout_test (id, name) VALUES(1, 'John Doe')""")
            res = yield self.dbcon.runOperation("""INSERT INTO monitor_scout_test (id, name) VALUES(2, 'Jane Doe')""")
        #        res = yield self.dbcon.runQuery("""SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'""")
        res = yield self.dbcon.runQuery('select id, name from monitor_scout_test')
        if len(res) < 1:
            self.setError('test query failed, no rows returned')

    @defer.inlineCallbacks
    def _runQueryWithoutDB(self):
        res = yield self.dbcon.runQuery('select 1')
        if len(res) < 1:
            self.setError('test query failed, no rows returned')
        print 'res', res

    def _hardTimeout(self, *args, **kwargs):
        self.setError('Timeout, session took to long')
        self._hard_timeout = None
        self.done()

    def done(self):
        try:
            self.dbcon.close()
        except:
            pass
        if self._hard_timeout:
            self._hard_timeout.cancel()
        if self._error:
            self.deferred.errback(self._error)
        else:
            self.deferred.callback('')

    def setError(self, error):
        if self._error is None:
            if type(error) is str:
                self._error = errors.HLProbeError(error)
            else:
                self._error = error
