import urlparse

from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import bin2
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class MSHTTPCDNMonitorJob(bin2.BaseBin2MonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [str, unicode],
        [str, unicode],
        [bool],
        [int],
        [bool]]
    name = 'monitor-http-cdn'
    executable = utils.get_monitor_binary('go-check-http')

    def _run(self, hostname, timeout, url, match_string, validate_ssl, ssl_warn_days, download_full):
        log.debug('%s._run starting _run.' % (self))
        try:
            args = self._makeDefaultArgs()
            if not url:
                url = hostname
            bin2_args = {'Url': url, 'Hostname': hostname, 'MatchString': match_string, 'Timeout': timeout, 'ValidateSSL': validate_ssl, 'SSLWarnDays': ssl_warn_days, 'DownloadFull': download_full}
        except Exception, e:
            self.result['errormsg'] = str(e)
            self.setFailure()
        else:
            self._runPlugin(self.executable, args, timeout, bin2_args)
registry.job_registry.register(MSHTTPCDNMonitorJob)

