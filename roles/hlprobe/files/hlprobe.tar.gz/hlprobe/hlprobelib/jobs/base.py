import threading
import time

from twisted.internet import reactor
from twisted.internet import threads
from twisted.internet.protocol import Protocol, ClientFactory
from twisted.protocols import policies
from twisted.python import failure
from twisted.internet import defer
import twisted.internet.utils
import twisted.internet.error

from hlprobelib import errors
from hlprobelib import utils
from hlprobelib import log


class Job(object):
    """Base class for all jobs."""
    arg_spec = []

    def __init__(self, queue, delegator_id, jobid, *args):
        self.queue = queue
        self.delegator_id = delegator_id
        self.jobid = jobid
        #        log.debug('%s.__init__ created new job.' % (self))
        #        log.debug('%s.__init__ job args: %s'% (self, str(args)))
        self.args = args
        self._validateArgs()
        self.completed = False
        self._lock = threading.Lock()
        self.created_time = time.time()
        self.started_time = None
        self.completed_time = None
        self._exception_raise = False
        self.result = {
            'status': '',
            'errormsg': '',
            'runtime': 0,
            'metrics': {},
        }

    def __str__(self):
        return '<Job "%s" id:%s (%s)>' % (self.__class__.__name__, self.jobid, self.args)

    def lock(self):
        self._lock.acquire()

    def unlock(self):
        self._lock.release()

    def setMetric(self, name, value):
        self.result['metrics'][name] = value

    def getMetric(self, name, default=None):
        return self.result['metrics'].get(name, default)

    @utils.with_lock
    def setComplete(self, status='success', set_response_time = True):
        self.completed = True
        self.completed_time = time.time()
        self.result['status'] = status
        self.result['runtime'] = self.completed_time - self.started_time
        if set_response_time:
            if 'response time' not in self.result:
                self.result['response time'] = self.result['runtime']
            if 'response time' not in self.result['metrics']:
                self.setMetric('response time', self.result['runtime'])
        log.debug('%s.setComplete called (runtime=%s, status=%s)' % (self, self.result['runtime'], status))
        self.queue.jobComplete(self)

    def setSuccess(self, set_response_time = True):
        return self.setComplete('success', set_response_time)

    def setFailure(self, set_response_time = False):
        return self.setComplete('failure', set_response_time)

    def setErrorMsg(self, msg):
        log.msg(msg)
        self.result['errormsg'] = str(msg)

    @utils.with_lock
    def isComplete(self):
        return self.completed

    @utils.with_lock
    def runTime(self):
        if self.completed:
            return self.result['runtime']
        else:
            return time.time() - self.started_time

    def _run(self):
        """Run the job.

        Should be overridden in subclasses.
        """
        self.setComplete()

    def run(self):
        self.started_time = time.time()
        #        log.debug('%s.run calling _run method.' % (self))
        self._run(*self.args)

    def _validateArgs(self):
        """Validate the arguments given to the job.

        Can be overriden in a subclass.
        """
        if len(self.args) != len(self.arg_spec):
            log.msg('%s._validateArgs, invalid argument count for job %d != %d.' % (
            self, len(self.args), len(self.arg_spec)))
            log.debug('arguments: %s' % (str(self.args)))
            raise errors.InvalidJobArgs()
        for pos, arg_types in enumerate(self.arg_spec):
            if arg_types is None:
                continue
            if type(self.args[pos]) not in arg_types:
                log.msg('%s._validateArgs, invalid argument types for job (pos: %d).' % (self, pos + 1))
                log.debug('arguments: %s' % (str(self.args)))
                raise errors.InvalidJobArgs()
        return True

    def _default_thread_error_cb(self, failure):
        log.msg('JobBase (jobid = %s) received an error from a thread: "%s"' % (self.jobid, str(failure)))
        self._exception_raise = True
        return None

    def _callInThread(self, func, set_default_errback, *args, **kwargs):
        """Run a function in a thread.

        Uses the twisted reactors thread pool per default.
        """
        d = threads.deferToThread(func, *args, **kwargs)
        if set_default_errback:
            d.addErrback(self._default_thread_error_cb)
        return d

    def _parseGenericErrors(self, error):
        ret = ''
        try:
            if hasattr(error, 'value'):
                if isinstance(error.value, twisted.internet.error.ConnectionRefusedError):
                    ret = 'Connection refused'
                elif isinstance(error.value, twisted.internet.error.TimeoutError):
                    ret = 'Timeout'
                else:
                    ret = str(error.value)
            else:
                ret = str(error)
        except Exception, e:
            log.msg('Error in _parseGenericErrors: %s' % (str(e)))
        return ret
