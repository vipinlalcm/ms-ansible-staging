from hlprobelib.jobs import base
from hlprobelib.jobs import registry
from hlprobelib.jobs import nagios
from hlprobelib import errors
from hlprobelib import log
from hlprobelib import utils


class IRCMonitorJob(nagios.BaseNagiosMonitorJob):
    arg_spec = [
        [str, unicode],
        [int],
        [int],
        [int]]
    name = 'monitor-irc'
#    executable = '/usr/lib/nagios/plugins/check_ircd'
    executable = utils.get_monitor_binary('check_ircd', style='nagios')

    def _run(self, hostname, timeout, port, max_users):
        log.debug('%s._run starting _run.' % (self))
        args = ['-H', hostname, '-p', port, '-w', max_users, '-c', max_users]
        self._runPlugin(self.executable, args, timeout)


nagios.register_job(IRCMonitorJob)
