import os.path
from twisted.internet import reactor
import twisted.internet.utils
from twisted.internet import defer
from twisted.internet import protocol
from twisted.protocols import policies
from twisted.internet.error import (ProcessDone, ProcessTerminated, ProcessExitedAlready)

try:
    import cStringIO as StringIO
except ImportError:
    import StringIO

from hlprobelib import log
from hlprobelib import recurringtask
from hlprobelib import errors

FPING_PATHS = [
    '/usr/bin/fping',
    '/opt/local/sbin/fping',
    '/usr/local/sbin/fping',
    '/usr/sbin/fping'
]

_fping_path = None
for fping_path in FPING_PATHS:
    if os.path.exists(fping_path):
        _fping_path = fping_path
        break

def set_fping_path(path):
    global _fping_path
    _fping_path = path

class ConnectivityChecker(recurringtask.RecurringTask):
    interval = 10
    max_response_time = 5

    def __init__(self, check_hosts, *args, **kwargs):
        super(ConnectivityChecker, self).__init__(*args, **kwargs)
        global _fping_path
        if not _fping_path or not os.path.isfile(_fping_path):
            raise Exception('unable to find fping executable, please set fping-path in CONNECTIVITYCHECKER section of configuration file')
        self._fping_cmdline = '%s -C 1 -q %%s' % (_fping_path)
        if type(check_hosts) in [str, unicode]:
            self.check_hosts = check_hosts.split()
        elif type(check_hosts) == list:
            self.check_hosts = check_hosts
        else:
            self.check_hosts = []
        if len(self.check_hosts) == 0:
            raise errors.HLProbeError('ConnectivityChecker.check_hosts is empty')
        self.is_alive = None
        self.setAlive(False)

    @defer.inlineCallbacks
    def _run(self):
        alive = False
        for hostname in self.check_hosts:
            cmdline = self._fping_cmdline % (hostname)
            split = cmdline.split(' ')
            try:
                proto = FpingProcessProtocol()
                reactor.spawnProcess(proto, split[0], split[0:])
                output = yield proto.deferred
            except Exception, e:
                log.msg('ConnectivityChecker fping call failed: %s' % (e))
                continue
            try:
                response_time = self._parseFpingOutput(hostname, output)
            except Exception, e:
                log.msg('%s unhandled exception in _parseFpingOutput: %s.' % (self, str(e)))
            if response_time != None and response_time > 0 and response_time < self.max_response_time:
                alive = True
                log.debug('ConnectivityChecker fping success for host %s: %s' % (hostname, response_time))
                break
            else:
                log.debug('ConnectivityChecker fping failed for host %s: %s' % (hostname, response_time))
        self.setAlive(alive)

    def setAlive(self, alive):
        if alive != self.is_alive:
            log.msg('ConnectivityChecker setting alive status to %s' % (alive))
            self.is_alive = alive

    def isAlive(self):
        return self.is_alive

    def _parseFpingOutput(self, hostname, output):
        response_time = None
        for line in output.split('\n'):
            line = line.strip()
            if not line.startswith(hostname):
                continue
            split = line.split(':')
            if len(split) != 2:
                continue
            value = split[1].strip()
            if value.startswith('duplicate'):
                continue
            response_time = value
            break
        if response_time == '-':
            response_time = -1
        else:
            # Return response time in seconds.
            try:
                response_time = float(response_time)
            except Exception, e:
                log.msg('%s._parseFpingOutput exception parsing output "%s": %s.' % (self, output, str(e)))
                response_time = None
            else:
                response_time /= 1000
        return response_time


class FpingProcessProtocol(protocol.ProcessProtocol, policies.TimeoutMixin):
    def __init__(self, timeout = 10):
        self.deferred = defer.Deferred()
        self._outdata = StringIO.StringIO()
        self._timedout = False
        self._process_ended_called = False
        self.setTimeout(timeout)

    def outReceived(self, data):
        self._outdata.write(data)
    errReceived = outReceived

    def processEnded(self, status):
        if not self._process_ended_called:
            self._process_ended_called = True
            self.setTimeout(None)
            if self._timedout:
                self.deferred.errback(Exception('timeout waiting for process'))
            else:
                self.deferred.callback(self._outdata.getvalue())
        else:
            log.msg('%s.processEnded called with _process_ended_called=True, strange.')

    def timeoutConnection(self):
        self._timedout = True
        if self._process_ended_called:
            log.msg('%s.timeoutConnection: process exited already called, this is strange.')
            return
        if self.transport:
            self.transport.loseConnection()
            try:
                self.transport.signalProcess('KILL')
            except ProcessExitedAlready:
                log.msg('%s.timeoutConnection: trying to kill process but it\'s already dead.')
