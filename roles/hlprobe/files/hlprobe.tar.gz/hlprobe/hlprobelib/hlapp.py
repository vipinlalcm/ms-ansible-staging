from optparse import OptionParser
import sys

from twisted.internet import reactor
from twisted.application import service, app

from hlprobelib import log
from hlprobelib import config
from hlprobelib import utils

def create_default_options():
    usage = 'usage: %prog [args ...]'
    parser = OptionParser(usage = usage)
    parser.add_option('-c', '--config', dest = 'config',
            help = 'config file to use (default /etc/hlrpcfront.conf)')
    parser.add_option('-l', '--log-file', dest = 'logfile',
            help = 'optional logfile to use')
    parser.add_option('-L', '--log-section', dest = 'log_section',
            help = 'only display logs for specified sections')
    parser.add_option('-d', '--daemon', dest = 'daemon', default = False,
            action = 'store_true', help = 'daemonize process')
    parser.add_option('-p', '--pid-file', dest = 'pidfile',
            help = 'option pidfile to use')
    return parser

def run_default_setup(argv, option_parser = None):
    if not option_parser:
        option_parser = create_default_options()
    if not argv:
        argv = sys.argv[1:]
    (options, args) = option_parser.parse_args(argv)

    if options.config:
        conf = config.Config(config_files = [options.config])
    else:
        conf = config.Config()

    section = conf.section('LOGGING')
    logfile = options.logfile
    if not logfile:
        logfile = section.get('file', error_if_missing = True)
    if options.log_section:
        options.log_section = options.log_section.split(',')
    log_rotate_length = section.getInt('rotate-length', error_if_missing = False)
    log_max_rotated_files = section.getInt('max-rotated-files', error_if_missing = False)
    log.configure_logging(logfile,
            section.get('debug-logging', False),
            options.log_section, log_rotate_length, log_max_rotated_files)

    return (conf, options, args)

def create_app(name, services):
    root_service = service.MultiService()
    for sub_service in services:
        sub_service.setServiceParent(root_service)
    application = service.Application(name)
    root_service.setServiceParent(application)
    return application

def startup(conf, options, application = None):
    log.msg('Starting reactor, launching hlapp') 
    if options.daemon: 
        utils.daemonize(options.pidfile) 
    if application:
        app.startApplication(application, False)
    reactor.run() 
    log.msg('Application shutting down')

