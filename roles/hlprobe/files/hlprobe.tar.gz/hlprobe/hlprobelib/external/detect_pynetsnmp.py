#!/usr/bin/env python

import sys

# This fixes both a missing pynetsnmp and pynetsnmp as distributed in
# Ubuntu 14.04 with a broken constants module.
try:
    import pynetsnmp
    import pynetsnmp.CONSTANTS
except (ImportError, NameError):
    pynetsnmp = None
if not pynetsnmp:
    sys.exit(1)
sys.exit(1)
sys.exit(0)
