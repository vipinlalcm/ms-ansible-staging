__doc__ = "pynetsnmp is a ctypes wrapper of net-snmp"
