import sys
import os.path
import subprocess

# We keep the external imports in the packages directory to avoid interfering
# with the auto detection.

# The autodetect scripts run as separate binaries because they need to
# import the modules that they are testing and it is not possible to
# unload python modules.

def set_import(name):
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'packages', name)
    if not os.path.isdir(path):
        raise Exception('invalid import path: %s' % path)
    sys.path.insert(0, path)

def detect(name):
    filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), name)
    ret = True
    try:
        subprocess.check_call(filename)
    except subprocess.CalledProcessError:
        ret = False
    return ret

def auto_detect():
    if not detect('detect_msgpack.py'):
        set_import('msgpack')
    if not detect('detect_pynetsnmp.py'):
        set_import('pynetsnmp')
