#!/usr/bin/env python

import sys

try:
    import msgpack
    if not hasattr(msgpack, 'version') or msgpack.version < (0, 4, 2):
        msgpack = None
except ImportError:
    msgpack = None
if not msgpack:
    sys.exit(1)
sys.exit(0)
