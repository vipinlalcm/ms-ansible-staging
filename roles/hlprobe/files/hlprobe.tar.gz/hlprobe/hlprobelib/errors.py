"""Exceptions and errors.."""

class HLProbeError(Exception):
    def __str__(self):
        if len(self.args) == 1:
            ret = self.args[0]
        else:
            ret = str(self.__class__.__name__)
        return ret

class InvalidJobType(HLProbeError):
    """Someone tried to create a job of an unknown type."""
    pass

class InvalidJobID(HLProbeError):
    """Invalid job id."""
    pass

class JobAlreadyExists(HLProbeError):
    """A job with the same jobid is already running."""
    pass

class JobIsRunning(HLProbeError):
    """Trying to do something bad to a running job."""
    pass

class InvalidJobArgs(HLProbeError):
    """Wrong number of arguments passed to a job."""
    pass

class ConfigError(HLProbeError):
    """Random error in the config file."""
    pass

class InvalidArgumentEncoding(HLProbeError):
    """Invalid encoding for an rpc command argument."""
    pass

class NoRPCClientsAvailable(HLProbeError):
    pass

class SNMPError(HLProbeError):
    pass

class InvalidSNMPAuthInfo(SNMPError):
    pass

class RPCClientError(HLProbeError):
    pass

class RPCClientTimeout(RPCClientError):
    pass

class NoRPCClientsAvailable(RPCClientError):
    pass

class RecurringTaskError(HLProbeError):
    pass

class ConfigError(HLProbeError):
    pass
