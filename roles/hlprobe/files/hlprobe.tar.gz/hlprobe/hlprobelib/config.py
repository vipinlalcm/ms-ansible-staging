"""Configuration file handling.

Adds very basic configuration file handling classes.
"""

import ConfigParser
import os
import os.path

from hlprobelib import errors

class Config(object):
    """Configuration objects base class.
    
    Parses a configuration file and has basic retrieval methods.
    """
    def __init__(self, config_files = []):
        self.conf = ConfigParser.SafeConfigParser()
        if type(config_files) in [str, unicode]:
            config_files = os.path.expanduser(config_files)
        else:
            config_files = [os.path.expanduser(p) for p in config_files]
        self.conf.read(config_files)

    def get(self, section, option, error_if_missing = False):
        """See if an option exists in the given section.
        
        The option value will be returned if it exists otherwise None.
        """
        if self.conf.has_option(section, option):
            return self.conf.get(section, option)
        if error_if_missing:
            raise errors.ConfigError('option "%s" in section "%s" is required.' % (
                option, section))
        return None

    def getInt(self, section, option, error_if_missing = False):
        val = self.get(section, option, error_if_missing)
        if val is None and error_if_missing:
            raise errors.ConfigError('option "%s" in section "%s" is required.' % (
                option, section))
        if val is not None:
            try:
                val = int(val)
            except ValueError:
                raise errors.ConfigError('option "%s" in section "%s" should be type(int)' % (
                    option, section))
        return val

    def getFloat(self, section, option, error_if_missing = False):
        val = self.get(section, option, error_if_missing)
        if val is not None:
            try:
                val = float(val)
            except ValueError:
                raise errors.ConfigError('option "%s" in section "%s" should be type(float)' % (
                    option, section))
        return val

    def getBool(self, section, option, error_if_missing = False):
        val = self.get(section, option, error_if_missing)
        if val is not None:
            val = val.lower()
            if val == 'true':
                val = True
            elif val == 'false':
                val = False
            else:
                raise errors.ConfigError('option "%s" in section "%s" should be type(bool)' % (
                    option, section))
        return val

    def has_option(self, section, option):
        return self.conf.has_option(section, option)

    def section(self, section):
        return Section(self, section)

    def default_section(self):
        return Section(self, 'DEFAULT')

class Section(object):
    def __init__(self, config, section):
        self.config = config
        self.section = section

    def get(self, option, error_if_missing = False):
        return self.config.get(self.section, option, error_if_missing)

    def getInt(self, option, error_if_missing = False):
        return self.config.getInt(self.section, option, error_if_missing)

    def getFloat(self, option, error_if_missing = False):
        return self.config.getFloat(self.section, option, error_if_missing)

    def getBool(self, option, error_if_missing = False):
        return self.config.getBool(self.section, option, error_if_missing)

    def has_option(self, option):
        return self.config.has_option(self.section, option)

