import socket
import platform
import os
import os.path
from twisted.internet import reactor, defer

from hlprobelib import errors
from hlprobelib import log

SYSLOADFILE = '/proc/loadavg'
CPUINFOFILE = '/proc/cpuinfo'

DEFAULT_MONITOR_BINARY_PATHS = [
    '/hlapps/apps/hlprobe-binaries',
    '/usr/lib/nagios/plugins/',
    '/usr/lib64/nagios/plugins/'
]

def get_monitor_binary(binary_name, base_path = None, style = 'platform'):
    if style == 'platform':
        ret = get_monitor_binary_style_platform(binary_name, base_path)
    elif style == 'nagios':
        ret = get_monitor_binary_style_nagios(binary_name, base_path)
    else:
        raise Exception('invalid get_monitor_binary style %s' % style)
    return ret

def get_monitor_binary_style_nagios(binary_name, base_path):
    if base_path:
        base_paths = DEFAULT_MONITOR_BINARY_PATHS + base_path
    else:
        base_paths = DEFAULT_MONITOR_BINARY_PATHS
    binary_path = None
    for base_path in base_paths:
        cur_path = os.path.join(base_path, binary_name)
        if os.path.isfile(cur_path):
            binary_path = os.path.abspath(cur_path)
            break
#    if not binary_path:
#        raise Exception('unable to find binary monitor path for %s' % binary_name)
    return binary_path

def get_monitor_binary_style_platform(binary_name, base_path):
    if base_path:
        base_paths = DEFAULT_MONITOR_BINARY_PATHS + base_path
    else:
        base_paths = DEFAULT_MONITOR_BINARY_PATHS
    platform_paths = ['generic']
    platform_path = _get_monitor_binary_platform_path()
    if platform_path:
        platform_paths.append(platform_path)
    binary_path = None
    for base_path in base_paths:
        for platform_path in platform_paths:
            cur_path = os.path.join(base_path, platform_path, binary_name)
            if os.path.isfile(cur_path):
                binary_path = os.path.abspath(cur_path)
                break
    if not binary_path:
        raise Exception('unable to find binary monitor path for %s' % binary_name)
    return binary_path

def _get_monitor_binary_platform_path():
    system = platform.system()
    bits = get_system_bits()
    ret = None
    if system == 'Darwin' and bits == 64:
        ret = 'darwin_amd64'
    elif system == 'Linux' and bits == 32:
        ret = 'linux_386'
    elif system == 'Linux' and bits == 64:
        ret = 'linux_amd64'
    return ret

def daemonize(pid_file = None):
    if os.fork():
        os._exit(0)
    os.setsid()
    pid = os.fork()
    if pid:
        if pid_file:
            fd = open(pid_file, 'w')
            fd.write(str(pid))
            fd.close()
        os._exit(0)
    null = os.open('/dev/null', os.O_RDWR)
    for i in range(3):
        try:
            os.dup2(null, i)
        except OSError, e:
            if e.errno != errno.EBADF:
                raise
    os.close(null)

def get_system_startup_timestamp():
    try:
        uptime_seconds, idle_seconds = open('/proc/uptime', 'r').read().strip().split()
        uptime_seconds = float(uptime_seconds)
        uptime_timestamp = time.time() - uptime_seconds
    except:
        uptime_timestamp = 0
    return uptime_timestamp

def get_system_bits():
    import platform
    bits, linkage = platform.architecture()
    if bits == '32bit':
        bits = 32
    elif bits == '64bit':
        bits = 64
    else:
        bits = None
    return bits

def d_sleep(length, deferred=None):
    """A twisted deferred sleep.

    Can be called with a yield in a inlineCallbacks wrapped function.
    """
    if deferred:
        deferred.callback(True)
        ret = True
    else:
        ret = defer.Deferred()
        reactor.callLater(length, d_sleep, length, ret)
    return ret

def with_lock(func):
    def lock(*args, **kwargs):
        try:
            args[0].lock()
            ret = func(*args, **kwargs)
            return ret
        finally:
            args[0].unlock()
    return lock

def get_system_load(num_cpus = None, interval = 1):
    """Returns the system load divided by the number of processors.

    Interval can be one of 1, 5 or 15 (number of minutes).
    """
    if interval not in [1, 5, 15]:
        raise errors.WorkerError('invalid interval passed to get_system_load')
    if num_cpus is None:
        num_cpus = get_num_cpus()
    if num_cpus < 1:
        num_cpus = 1
    rfd = open(SYSLOADFILE, 'r')
    loadline = rfd.read(1024)
    rfd.close()
    split = loadline.split()
    if len(split) != 5:
        log.msg('get_system_load unable to parse format of SYSLOADFILE.')
        return None
    val = None
    if interval == 1:
        val = split[0]
    elif interval == 5:
        val = split[1]
    elif interval == 15:
        val = split[2]
    try:
        val = float(val)
    except ValueError:
        log.msg('get_system_load unable to parse format of SYSLOADFILE.')
        return None
    val /= num_cpus
    return val

def get_num_cpus():
    """Return the number of cpus/cores in the system.

    Simply counts the number of 'processor' lines in /proc/cpuinfo.
    """
    count = 0
    for line in open(CPUINFOFILE):
        if line.startswith('processor'):
            count += 1
    return count

