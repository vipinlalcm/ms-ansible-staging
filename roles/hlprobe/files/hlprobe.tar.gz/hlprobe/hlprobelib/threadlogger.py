from twisted.internet import reactor, defer

from hlprobelib import recurringtask
from hlprobelib import log

class ThreadLogTask(recurringtask.RecurringTask):
    interval = 30

    def __init__(self, twisted_threadpools = None):
        super(ThreadLogTask, self).__init__()
        if twisted_threadpools is None:
            from twisted.internet import reactor
            self.twisted_threadpools = [reactor.getThreadPool()]
        else:
            self.twisted_threadpools = twisted_threadpools

    def _run(self):
        import threading
        log.debug('------------ Thread Logger ------------')
        log.debug('THREADLOG: Number of active threads: %s' % (threading.active_count()))
        for tp in self.twisted_threadpools:
            log.debug('THREADLOG: %s: min:%d max:%d total:%d workers:%d waiters:%d queue:%d' % (tp.name, tp.min, tp.max, len(tp.threads), len(tp.working), len(tp.waiters), tp.q.qsize()))
        log.debug('---------------------------------------')
        return defer.succeed(True)

def run_thread_logger(interval = 30, twisted_threadpools = None):
    task = ThreadLogTask(twisted_threadpools)
    task.interval = interval
    reactor.callWhenRunning(task.start)

