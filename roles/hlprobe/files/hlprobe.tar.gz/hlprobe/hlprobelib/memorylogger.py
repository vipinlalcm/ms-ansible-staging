from twisted.internet import reactor, defer

from hlprobelib import recurringtask
from hlprobelib import log

def get_my_memory_usage():
    """Memory usage of the current process in kilobytes."""
    status = None
    result = {'VmPeak': 0, 'VmSize': 0, 'VmRSS': 0}
    try:
        # This will only work on systems with a /proc file system
        # (like Linux).
        status = open('/proc/self/status')
        for line in status:
            parts = line.split()
            key = parts[0][:-1]
            if key in result:
                result[key] = int(parts[1])
    except IOError:
        # status probably didn't exist.
        pass
    finally:
        if status is not None:
            status.close()
    return result

class MemoryLogTask(recurringtask.RecurringTask):
    interval = 30

    def __init__(self):
        super(MemoryLogTask, self).__init__()

    def _run(self):
        memory_usage = get_my_memory_usage()
        log.debug('------------ Memory Logger ------------')
        for memory_type in memory_usage:
            log.debug('MEMLOG: %s: %s' % (memory_type, memory_usage[memory_type]))
        log.debug('---------------------------------------')
        return defer.succeed(True)

def run_memory_logger(interval = 30):
    task = MemoryLogTask()
    task.interval = interval
    reactor.callWhenRunning(task.start)

