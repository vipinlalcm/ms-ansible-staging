from twisted.internet import reactor
from twisted.internet import task

from hlprobelib.jobs.registry import job_registry
from hlprobelib.jobs import errorjob
from hlprobelib import errors
from hlprobelib import log

MAX_THREADS = 10

class JobQueue(object):
    def __init__(self, max_threads = MAX_THREADS):
        self.manager = None
        self.max_threads = max_threads
        self.jobs = {}
        self.run_job_count = 0
        reactor.suggestThreadPoolSize(self.max_threads)
        if reactor.threadpool is None:
            reactor._initThreadPool()
        log.msg('JobQueue started (max_threads = %d).' % (self.max_threads))

    def runJob(self, delegator_id, jobid, jobtype, args):
        self.run_job_count += 1
        job = None
        if jobtype not in job_registry.jobtypes:
            log.msg('JobQueue asked to run job of invalid type "%s".' % (jobtype))
            job = errorjob.ErrorJob(self, delegator_id, jobid, 'invalid job type', *args)
        else:
            try:
                job = job_registry.jobtypes[jobtype](self, delegator_id, jobid, *args)
            except Exception, e:
                log.msg('JobQueue failed to init job: "%s".' % (str(e)))
                job = errorjob.ErrorJob(self, delegator_id, jobid, str(e), *args)
        if not isinstance(job, errorjob.ErrorJob):
            try:
                job.run()
            except Exception, e:
                log.err('JobQueue failed to run job %s: %s' % (jobid, e))
                job = errorjob.ErrorJob(self, delegator_id, jobid, 'failed to run job: %s' % (e), *args)
        if isinstance(job, errorjob.ErrorJob):
            self.jobComplete(job)
        if not job.completed:
            self.jobs[jobid] = job
        return job

    def jobComplete(self, job):
        self.removeJob(job.jobid)
        self.manager.jobComplete(job)

    def getJob(self, jobid):
        if not jobid in self.jobs:
            log.msg('JobQueue.getJob asked for invalid jobid "%s"' % (jobid))
            raise errors.InvalidJobID()
        return self.jobs[jobid]

    def removeJob(self, jobid):
        if jobid in self.jobs:
            del self.jobs[jobid]

    def iterJobs(self):
        """Iterate over all existing jobs."""
        return self.jobs.itervalues()

    def iterRunningJobs(self):
        """Iterate over all running jobs."""
        for jobid in self.jobs:
            job = self.jobs[jobid]
            if not job.isComplete():
                yield job

    def iterCompletedJobs(self):
        """Iterate over all completed jobs.

        Only includes completed jobs that haven't been removed.
        """
        for jobid in self.jobs:
            job = self.jobs[jobid]
            if job.isComplete():
                yield job

    def numQueuedJobs(self):
        """Return number of jobs currently waiting for a thread to run in."""
        return reactor.threadpool.q.qsize()

    def numWorkingThreads(self):
        """Return the number of working threads."""
        return len(reactor.threadpool.working)

    def numIdleThreads(self):
        """Return the number of idle threads."""
        return len(reactor.threadpool.waiters)

