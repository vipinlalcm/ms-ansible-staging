import time
import xmlrpclib
import random
from twisted.web.xmlrpc import Proxy
from twisted.internet import reactor
from twisted.internet import defer
from twisted.python import failure

from hlprobelib import log
from hlprobelib import errors
from hlprobelib import utils
from hlprobelib import recurringtask

class _RPCProxy(object):
    disable_time_max = 600
    disable_time_step = 30

    def __init__(self, hostname, port, skip_disable):
        self.proxy_url = 'http://%s:%d/RPC2/' % (hostname, port)
        self.proxy = Proxy(self.proxy_url)
        self.disable_time_len = 0
        self.skip_disable = skip_disable
        self.enable()

    def _getDisableTime(self):
        active_time = time.time() - self.activade_time
        if active_time < 30:
            self.disable_time_len += self.disable_time_step
        else:
            self.disable_time_len = self.disable_time_step
        return self.disable_time_len

    def disable(self):
        if not self.active:
            return
        if self.skip_disable:
            return
        self.active = False
        disable_time = self._getDisableTime()
        log.msg('disabling rpc client proxy %s for %ss' % (
            self.proxy_url, disable_time), 'rpcclient')
        reactor.callLater(disable_time, self.enable)

    def enable(self):
        log.debug('enabling rpc client proxy %s' % (self.proxy_url), 'rpcclient')
        self.active = True
        self.activade_time = time.time()

    def call(self, *args, **kwargs):
        log.debug('remote call %s %s' % (args, kwargs), 'rpcclient')
        return self.proxy.callRemote(*args, **kwargs)

class _RPCCommand(object):
    def __init__(self, proxies, timeout, disable_on_rpc_fault,
            *args, **kwargs):
        self.proxies = proxies
        self.disable_on_rpc_fault = disable_on_rpc_fault
        self.args = args
        self.kwargs = kwargs
        self.prev_proxy = None
        self.prev_error = None
        self.deferred = defer.Deferred()
        self._timed_out = False
        self._call_start = 0
        self._call_end = 0
        if timeout:
            self._timeout_dc = reactor.callLater(timeout, self._cbTimeout)
        self._call()

    def _getProxy(self):
        ret = None
        for proxy in self.proxies:
            if proxy == self.prev_proxy:
                continue
            if not proxy.active:
                continue
            ret = proxy
            break
        if not ret:
            if self.prev_error:
                _error = self.prev_error
            else:
                _error = errors.NoRPCClientsAvailable()
            log.msg('unable to find an active rpc proxy, giving up', 'rpcclient')
            self._cancelTimeout()
            self.deferred.errback(_error)
        return ret

    def _call(self):
        self.prev_proxy = self._getProxy()
        if not self.prev_proxy:
            return
        self._call_start = time.time()
        d = self.prev_proxy.call(*self.args, **self.kwargs)
        d.addCallbacks(self._cbCall, self._ebCall)

    def _cbCall(self, result):
        self._call_end = time.time()
        log.debug('rpc client call succeeded, elapsed=%s' % (self._call_end - self._call_start), 'rpcclient')
        self._cancelTimeout()
        if self._timed_out:
            return
        self.deferred.callback(result)

    def _ebCall(self, error):
        self._call_end = time.time()
        if self._timed_out:
            return
        # If we received an xmlrpc.Fault there probably isn't really
        # anything wrong with the other end other than an inability
        # to deal with our call.
        if type(error.value) == xmlrpclib.Fault and not \
                self.disable_on_rpc_fault:
            log.msg('rpc client call received rpc fault, bailing out: %s' % (
                error.value), 'rpcclient')
            self._cancelTimeout()
            self.deferred.errback(error)
            return
        log.msg('rpc client call failed, trying next client: %s' % (
            error.value), 'rpcclient')
        self.prev_proxy.disable()
        self.prev_error = error
        self._call()

    def _cancelTimeout(self):
        if self._timeout_dc:
            self._timeout_dc.cancel()
            self._timeout_dc = False

    def _cbTimeout(self):
        if not self._timed_out:
            log.msg('rpc client call timed out', 'rpcclient')
            self._timed_out = True
            self._timeout_dc = False
            self.deferred.errback(errors.RPCClientTimeout('timeout waiting for response'))

class RPCClient(recurringtask.RecurringTask):
    call_timeout = 60 # seconds

    def __init__(self, rpc_servers, skip_disable = False,
            disable_on_rpc_fault = False, update_method = None,
            update_args = (), update_interval = 60):
        self.disable_on_rpc_fault = disable_on_rpc_fault
        self.skip_disable = skip_disable
        self._initProxies(rpc_servers)
        self.update_method = update_method
        self.update_args = update_args
        self.interval = update_interval

    def _initProxies(self, rpc_servers):
        log.debug('RPCClient init proxies: %s' % (rpc_servers))
        self.proxies = []
        self.proxy_data = set()
        for hostname, port in rpc_servers:
            if type(hostname) == unicode:
                hostname = hostname.encode('utf-8')
            self.proxy_data.add((hostname, port))
            self.proxies.append(_RPCProxy(hostname, port, self.skip_disable))
        random.shuffle(self.proxies)

    def _start(self):
        return self._updateProxies()
    _run = _start

    @defer.inlineCallbacks
    def _updateProxies(self):
        if not self.update_method:
            defer.returnValue(False)
        proxy_data = set()
        rpc_servers = yield self.update_method(*self.update_args)
        # Need to make sure we're using tuples, not lists.
        for hostname, port in rpc_servers:
            proxy_data.add((hostname, port))
        if proxy_data != self.proxy_data:
            self._initProxies(rpc_servers)

    def call(self, *args, **kwargs):
        cmd = _RPCCommand(self.proxies, self.call_timeout,
                self.disable_on_rpc_fault, *args, **kwargs)
        return cmd.deferred

    @defer.inlineCallbacks
    def retriedCall(self, attempts=5, attempt_delay=30, *args, **kwargs):
        calls = 0
        res = None
        while True:
            try:
                res = yield self.call(*args, **kwargs)
                break
            except Exception, e:
                log.msg('%s.retriedCall attempt failed: %s' % (self, e))
            calls += 1
            if calls >= attempts:
                log.msg('%s.retriedCall, giving up.' % (self))
                break
            log.msg('%s.retriedCall, sleeping %ss then retrying.' % (self, attempt_delay))
            yield utils.d_sleep(attempt_delay)
        defer.returnValue(res)

    def isActive(self):
        """Check if the rpcclient has any active proxies.
        
        Returns True if there are any active proxies, otherwise False.
        """
        for proxy in self.proxies:
            if proxy.active:
                return True
        return False

class MultiClientSubmit(object):
    def __init__(self, clients, randomize, *args, **kwargs):
        self.clients = clients
        if type(self.clients) is not list:
            self.clients = list(self.clients)
        if randomize:
            random.shuffle(self.clients)
        self.args = args
        self.kwargs = kwargs
        self.deferred = defer.Deferred()
        self.current_client = None
        self.current_data = None
        self._call()

    def _call(self):
        while True:
            if len(self.clients) == 0:
                self._abort(errors.NoRPCClientsAvailable())
                return
            self.current_client, self.current_data = self.clients.pop(0)
            if self.current_client.isActive():
                break
        d = self.current_client.call(*self.args, **self.kwargs)
        d.addCallbacks(self._cbCall, self._ebCall)

    def _cbCall(self, value):
        result = (value, self.current_client, self.current_data)
        self.deferred.callback(result)
        self.clients = None

    def _ebCall(self, error):
        log.debug('MultiClientSubmit error submitting to client "%s", trying again: %s' % (
            self.current_client, error), 'rpcclient')
        self._call()

    def _abort(self, error):
        log.msg('MultiClientSubmit call failed, no available clients',
                'rpcclient')
        self.clients = None
        self.deferred.errback(error)

